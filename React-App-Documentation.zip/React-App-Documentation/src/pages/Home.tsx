import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { useEffect } from 'react'
import { componentsRegistry } from '@/pages/Components/registry'

export default function Home() {
  useEffect(() => {
    document.title = 'Crystal UI - Pure CSS Components Library'
    const metaDescription = document.querySelector('meta[name="description"]')
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Crystal UI is a pure CSS library - no React required! Use beautiful components with just HTML and CSS. Perfect for vanilla projects, PHP, Python, and static sites.')
    }
  }, [])

  // Select some popular components for showcase
  const showcaseComponents = componentsRegistry.filter(c => 
    ['button', 'card', 'input', 'badge', 'alert', 'dialog'].includes(c.slug)
  )

  return (
    <main className="mx-auto max-w-6xl px-4 py-12">
      <h1 className="text-4xl font-bold">Crystal UI</h1>
      <p className="mt-3 max-w-2xl text-lg text-muted-foreground">
        Build beautiful interfaces with <strong className="text-foreground">pure CSS components</strong>. <br/>Inspired by Shadcn/ui. No React, no JavaScript framework required - just HTML and CSS classes.
      </p>
      <div className="mt-6 text-sm text-muted-foreground space-y-2 max-w-2xl">
        <p>✨ <strong className="text-foreground">Pure CSS</strong> - All components work with HTML and CSS only</p>
        <p>🚀 <strong className="text-foreground">No Framework Required</strong> - Use in any HTML project</p>
        <p>🎨 <strong className="text-foreground">Modern Design</strong> - Beautiful, accessible components</p>
        <p>📦 <strong className="text-foreground">Lightweight</strong> - Single CSS file, easy to integrate</p>
      </div>
      <div className="mt-8 flex gap-3">
        <Link to="/docs">
          <Button>Get Started</Button>
        </Link>
        <Link to="/components">
          <Button variant="outline">Browse Components</Button>
        </Link>
      </div>
      <div className="mt-12 p-6 border rounded-lg bg-muted/50">
        <h2 className="text-2xl font-semibold mb-4">Why Crystal UI?</h2>
        <p className="text-muted-foreground mb-4">
          A lightweight CSS library designed for modern web development. Works everywhere - from vanilla JavaScript to PHP, Python, static sites, and more.
        </p>
        <ul className="list-disc list-inside space-y-2 text-muted-foreground">
          <li>Perfect for vanilla JavaScript projects, PHP, Python Flask/Django, static sites</li>
          <li>All components are CSS-only - no JavaScript dependencies</li>
          <li>Beautiful design tokens and theming support</li>
          <li>Easy to integrate - just include one CSS file</li>
        </ul>
      </div>
      
      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-6">Featured Components</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {showcaseComponents.map((component) => (
            <Link
              key={component.slug}
              to={`/components/${component.slug}`}
              className="block p-6 border rounded-lg hover:bg-muted/50 transition-colors"
            >
              <h3 className="text-lg font-semibold mb-2">{component.name}</h3>
              <p className="text-sm text-muted-foreground">{component.description}</p>
            </Link>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Link to="/components">
            <Button variant="outline">View All Components</Button>
          </Link>
        </div>
      </div>
    </main>
  )
}


