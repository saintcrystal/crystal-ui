import { Link } from 'react-router-dom'
import { BookOpen, Download, Palette, Code2, Settings } from 'lucide-react'
import { SEO } from '@/components/SEO'

const docsPages = [
  {
    to: '/docs/getting-started',
    title: 'Getting Started',
    description: 'Quick start guide and basic usage examples',
    icon: BookOpen,
  },
  {
    to: '/docs/installation',
    title: 'Installation',
    description: 'How to install and include crystal-ui.css in your project',
    icon: Download,
  },
  {
    to: '/docs/theming',
    title: 'Theming',
    description: 'Learn about light and dark themes, and how to switch between them',
    icon: Palette,
  },
  {
    to: '/docs/css-variables',
    title: 'CSS Variables',
    description: 'Complete reference of all available CSS custom properties',
    icon: Code2,
  },
  {
    to: '/docs/customization',
    title: 'Customization',
    description: 'How to customize components and extend the library',
    icon: Settings,
  },
]

export default function DocsIndex() {
  return (
    <>
      <SEO
        title="Documentation - Crystal UI | How to Use Shadcn CSS Components"
        description="Complete documentation for Crystal UI - learn how to use Shadcn-style components with pure CSS. Installation, theming, customization guides."
        keywords="crystal ui documentation, shadcn css documentation, shadcn without react tutorial, pure css components guide"
        path="/docs"
      />
      <main className="mx-auto max-w-6xl px-4 py-12">
      <div className="mb-10">
        <h1 className="text-4xl font-bold mb-3">Documentation</h1>
        <p className="text-lg text-muted-foreground">
          Find instructions for installation, theming, and component integration.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {docsPages.map((page) => {
          const Icon = page.icon
          return (
            <Link
              key={page.to}
              to={page.to}
              className="group block p-6 rounded-lg border bg-card hover:bg-muted/50 transition-all hover:shadow-md"
            >
              <div className="flex items-start gap-4">
                <div className="p-2 rounded-md bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold mb-1 group-hover:text-primary transition-colors">
                    {page.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">{page.description}</p>
                </div>
              </div>
            </Link>
          )
        })}
      </div>
    </main>
    </>
  )
}
