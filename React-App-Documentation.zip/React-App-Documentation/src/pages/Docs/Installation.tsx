import { DocsLayout, CodeBlock } from '@/components/docs/DocsLayout'
import { Button } from '@/components/ui/button'
import { SEO } from '@/components/SEO'

export default function Installation() {
  return (
    <>
      <SEO
        title="Installation - Crystal UI | How to Install Shadcn CSS Library"
        description="Learn how to install Crystal UI - include crystal-ui.css via CDN or download. No build step, no React required. Perfect for vanilla HTML projects."
        keywords="crystal ui installation, shadcn css install, shadcn css cdn, crystal ui cdn, shadcn without react setup"
        path="/docs/installation"
      />
      <DocsLayout>
      <h1>Installation</h1>
      <p>
        Crystal UI is a standalone CSS library. Simply include the CSS file in your project—no JavaScript or build step required.
      </p>

      <h2>Method 1: Download and Include</h2>
      <p>Download the CSS file and include it in your HTML:</p>
      <CodeBlock language="html">{`<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="https://crystal-ui.com/v1/crystal-ui.css" />
  </head>
  <body>
    <button class="cui-btn cui-btn--primary">Button</button>
  </body>
</html>`}</CodeBlock>

      <div className="my-6">
        <a href="https://crystal-ui.com/v1/crystal-ui.css" download>
          <Button>Download crystal-ui.css</Button>
        </a>
      </div>

      <h2>Method 2: Direct Link</h2>
      <p>Include directly from our CDN:</p>
      <CodeBlock language="html">{`<link rel="stylesheet" href="https://crystal-ui.com/v1/crystal-ui.css" />`}</CodeBlock>

      <h2>Theme Setup</h2>
      <p>For dark theme support, add the <code>dark</code> class to your HTML element:</p>
      <CodeBlock language="html">{`<html class="dark">
  <!-- Your content -->
</html>`}</CodeBlock>

      <div className="bg-muted/50 border rounded-lg p-4 my-6">
        <p className="text-sm text-muted-foreground m-0">
          💡 <strong>Tip:</strong> Learn more about theming in the <a href="/docs/theming">Theming</a> guide.
        </p>
      </div>
    </DocsLayout>
    </>
  )
}
