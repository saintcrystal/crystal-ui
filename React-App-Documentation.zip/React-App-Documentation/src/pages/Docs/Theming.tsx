import { DocsLayout, CodeBlock } from '@/components/docs/DocsLayout'

export default function Theming() {
  return (
    <DocsLayout>
      <h1>Theming</h1>
      <p>
        Crystal UI supports two themes: <strong>light</strong> and <strong>dark</strong>.
        The library uses CSS variables that automatically switch based on the theme class.
      </p>

      <h2>Basic Usage</h2>
      <p>Add the <code>dark</code> class to your HTML element to enable dark theme:</p>
      <CodeBlock language="html">{`<html class="dark">
  <body>
    <button class="cui-btn cui-btn--primary">Button</button>
  </body>
</html>`}</CodeBlock>

      <h2>Theme Variables</h2>
      <p>All colors are controlled by CSS variables:</p>
      <ul>
        <li><code>--primary</code> - Primary color for buttons and accents</li>
        <li><code>--primary-foreground</code> - Text color on primary background</li>
        <li><code>--background</code> - Page background color</li>
        <li><code>--foreground</code> - Main text color</li>
        <li><code>--muted</code> - Muted background for hover states</li>
        <li><code>--border</code> - Border color</li>
        <li><code>--input</code> - Input border color</li>
        <li><code>--radius</code> - Border radius for rounded corners</li>
      </ul>

      <h2>Customizing Colors</h2>
      <p>
        Override CSS variables in your own stylesheet to customize the theme:
      </p>
      <CodeBlock language="css">{`:root {
  --primary: 220 90% 56%;
  --radius: 12px;
}`}</CodeBlock>

      <div className="bg-muted/50 border rounded-lg p-4 my-6">
        <p className="text-sm text-muted-foreground m-0">
          💡 <strong>Tip:</strong> See the <a href="/docs/css-variables">CSS Variables</a> page for a complete list of available variables.
        </p>
      </div>
    </DocsLayout>
  )
}
