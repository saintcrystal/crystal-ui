import { DocsLayout, CodeBlock } from '@/components/docs/DocsLayout'

export default function Customization() {
  return (
    <DocsLayout>
      <h1>Customization</h1>
      <p>
        Crystal UI components can be customized through CSS variables, additional classes, or by overriding styles.
      </p>

      <h2>CSS Variables</h2>
      <p>
        The easiest way to customize is by overriding CSS variables. This keeps your styles consistent with the library.
      </p>
      <CodeBlock language="css">{`:root {
  --primary: 220 90% 56%;
  --radius: 16px;
}`}</CodeBlock>

      <h2>Extending Components</h2>
      <p>Create custom variants by extending base classes:</p>
      <CodeBlock language="css">{`.cui-btn--custom {
  background: linear-gradient(135deg, hsl(var(--primary)), hsl(var(--muted)));
  border: none;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}`}</CodeBlock>

      <h2>Overriding Styles</h2>
      <p>Override specific styles with higher specificity:</p>
      <CodeBlock language="css">{`.my-button.cui-btn--primary {
  background: #ff0000;
  padding: 0 24px;
}`}</CodeBlock>

      <h2>Best Practices</h2>
      <ul>
        <li>Use CSS variables for colors to maintain theme support</li>
        <li>Keep custom styles in a separate file to preserve library updates</li>
        <li>Use modifier classes instead of inline styles when possible</li>
        <li>Test your customizations in both light and dark themes</li>
      </ul>

      <div className="bg-muted/50 border rounded-lg p-4 my-6">
        <p className="text-sm text-muted-foreground m-0">
          💡 <strong>Tip:</strong> See <a href="/docs/css-variables">CSS Variables</a> for a complete list of available customization options.
        </p>
      </div>
    </DocsLayout>
  )
}
