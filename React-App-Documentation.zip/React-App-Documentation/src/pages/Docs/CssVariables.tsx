import { DocsLayout, CodeBlock } from '@/components/docs/DocsLayout'

export default function CssVariables() {
  return (
    <DocsLayout>
      <h1>CSS Variables</h1>
      <p>
        Crystal UI uses CSS custom properties (variables) for all colors and sizing.
        This allows easy theming and customization without modifying the core library.
      </p>

      <h2>Color Variables</h2>
      <div className="overflow-x-auto my-6">
        <table className="min-w-full border-collapse">
          <thead>
            <tr className="border-b">
              <th className="text-left p-3 font-semibold">Variable</th>
              <th className="text-left p-3 font-semibold">Light Theme</th>
              <th className="text-left p-3 font-semibold">Dark Theme</th>
              <th className="text-left p-3 font-semibold">Usage</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--background</code></td>
              <td className="p-3"><code className="text-xs">0 0% 100%</code></td>
              <td className="p-3"><code className="text-xs">240 10% 3.9%</code></td>
              <td className="p-3 text-sm text-muted-foreground">Page background</td>
            </tr>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--foreground</code></td>
              <td className="p-3"><code className="text-xs">240 10% 3.9%</code></td>
              <td className="p-3"><code className="text-xs">0 0% 98%</code></td>
              <td className="p-3 text-sm text-muted-foreground">Main text color</td>
            </tr>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--primary</code></td>
              <td className="p-3"><code className="text-xs">240 5.9% 10%</code></td>
              <td className="p-3"><code className="text-xs">0 0% 98%</code></td>
              <td className="p-3 text-sm text-muted-foreground">Primary button color</td>
            </tr>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--primary-foreground</code></td>
              <td className="p-3"><code className="text-xs">0 0% 98%</code></td>
              <td className="p-3"><code className="text-xs">240 5.9% 10%</code></td>
              <td className="p-3 text-sm text-muted-foreground">Text on primary background</td>
            </tr>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--muted</code></td>
              <td className="p-3"><code className="text-xs">240 4.8% 95.9%</code></td>
              <td className="p-3"><code className="text-xs">240 3.7% 15.9%</code></td>
              <td className="p-3 text-sm text-muted-foreground">Muted backgrounds, hover states</td>
            </tr>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--border</code></td>
              <td className="p-3"><code className="text-xs">240 5.9% 90%</code></td>
              <td className="p-3"><code className="text-xs">240 3.7% 15.9%</code></td>
              <td className="p-3 text-sm text-muted-foreground">Border colors</td>
            </tr>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--input</code></td>
              <td className="p-3"><code className="text-xs">240 5.9% 90%</code></td>
              <td className="p-3"><code className="text-xs">240 3.7% 15.9%</code></td>
              <td className="p-3 text-sm text-muted-foreground">Input borders</td>
            </tr>
          </tbody>
        </table>
      </div>

      <h2>Sizing Variables</h2>
      <div className="overflow-x-auto my-6">
        <table className="min-w-full border-collapse">
          <thead>
            <tr className="border-b">
              <th className="text-left p-3 font-semibold">Variable</th>
              <th className="text-left p-3 font-semibold">Default Value</th>
              <th className="text-left p-3 font-semibold">Usage</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b hover:bg-muted/50">
              <td className="p-3"><code>--radius</code></td>
              <td className="p-3"><code>8px</code></td>
              <td className="p-3 text-sm text-muted-foreground">Border radius for rounded corners</td>
            </tr>
          </tbody>
        </table>
      </div>

      <h2>Using Variables</h2>
      <p>Use variables in your CSS:</p>
      <CodeBlock language="css">{`.custom-element {
  background: hsl(var(--primary));
  color: hsl(var(--primary-foreground));
  border-radius: var(--radius);
}`}</CodeBlock>

      <h2>Overriding Variables</h2>
      <p>Override any variable in your stylesheet:</p>
      <CodeBlock language="css">{`:root {
  --primary: 220 90% 56%;
  --radius: 12px;
}

.dark {
  --primary: 217 91% 60%;
}`}</CodeBlock>
    </DocsLayout>
  )
}
