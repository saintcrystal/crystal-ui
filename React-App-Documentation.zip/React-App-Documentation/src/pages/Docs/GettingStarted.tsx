import { DocsLayout, CodeBlock } from '@/components/docs/DocsLayout'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { ArrowRight } from 'lucide-react'
import { SEO } from '@/components/SEO'

export default function GettingStarted() {
  return (
    <>
      <SEO
        title="Getting Started - Crystal UI | Quick Start Guide"
        description="Get started with Crystal UI - the pure CSS alternative to Shadcn/ui. Learn how to include crystal-ui.css and use components with just HTML and CSS."
        keywords="crystal ui getting started, shadcn css quick start, shadcn without react tutorial, pure css components tutorial"
        path="/docs/getting-started"
      />
      <DocsLayout>
      <h1>Getting Started</h1>
      <p>
        Crystal UI is a lightweight CSS library that provides ready-to-use component styles.
        You can use it in any project by including the CSS file and applying the provided classes.
      </p>

      <h2>Quick Start</h2>
      <p>1. Include the CSS file in your HTML:</p>
      <CodeBlock language="html">{`<link rel="stylesheet" href="https://crystal-ui.com/v1/crystal-ui.css" />`}</CodeBlock>

      <p>2. Use the component classes:</p>
      <CodeBlock language="html">{`<button class="cui-btn cui-btn--primary">Click me</button>`}</CodeBlock>

      <h2>Download</h2>
      <p>
        Download <code>crystal-ui.css</code> from the repository or use it via CDN.
        The file contains all component styles and CSS variables for theming.
      </p>
      
      <div className="my-6">
        <a href="https://crystal-ui.com/v1/crystal-ui.css" download>
          <Button>Download crystal-ui.css</Button>
        </a>
      </div>

      <h2>Next Steps</h2>
      <div className="grid gap-4 mt-6 sm:grid-cols-2">
        <Link to="/components" className="block p-4 rounded-lg border hover:bg-muted transition-colors">
          <h3 className="font-semibold mb-1 text-foreground">Browse Components</h3>
          <p className="text-sm text-muted-foreground">See all available components with examples and code</p>
          <ArrowRight className="h-4 w-4 mt-2 text-muted-foreground" />
        </Link>
        <Link to="/docs/theming" className="block p-4 rounded-lg border hover:bg-muted transition-colors">
          <h3 className="font-semibold mb-1 text-foreground">Learn Theming</h3>
          <p className="text-sm text-muted-foreground">Customize colors and switch between light and dark themes</p>
          <ArrowRight className="h-4 w-4 mt-2 text-muted-foreground" />
        </Link>
      </div>
    </DocsLayout>
    </>
  )
}
