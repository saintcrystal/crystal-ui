import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'alert-dialog',
  name: 'Alert Dialog',
  description: 'A modal dialog that interrupts the user with important content and expects a response',
}

const html = `<input type="checkbox" id="cui-dialog-trigger" class="cui-dialog-checkbox" />
<div class="cui-dialog-overlay">
  <label for="cui-dialog-trigger" class="cui-dialog-overlay-bg"></label>
  <div class="cui-dialog-content">
    <div class="cui-dialog-header">
      <h2 class="cui-dialog-title">Are you absolutely sure?</h2>
      <p class="cui-dialog-description">
        This action cannot be undone. This will permanently delete your account and remove your data from our servers.
      </p>
    </div>
    <div class="cui-dialog-footer">
      <label for="cui-dialog-trigger" class="cui-btn cui-btn--outline">Cancel</label>
      <label for="cui-dialog-trigger" class="cui-btn cui-btn--primary">Continue</label>
    </div>
  </div>
</div>
<label for="cui-dialog-trigger" class="cui-btn cui-btn--primary">Open Dialog</label>`

const css = `.cui-dialog-checkbox {
  display: none;
}

.cui-dialog-overlay {
  position: fixed;
  inset: 0;
  z-index: 50;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
}

.cui-dialog-checkbox:checked ~ .cui-dialog-overlay {
  opacity: 1;
  pointer-events: auto;
}

.cui-dialog-overlay-bg {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  cursor: pointer;
}

.cui-dialog-content {
  position: relative;
  z-index: 1;
  max-width: 32rem;
  width: 100%;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 24px;
  opacity: 0;
  transform: scale(0.95) translateY(-10px);
  transition: opacity 0.15s ease, transform 0.15s ease;
}

.cui-dialog-checkbox:checked ~ .cui-dialog-overlay .cui-dialog-content {
  opacity: 1;
  transform: scale(1) translateY(0);
}

.cui-dialog-header {
  margin-bottom: 24px;
}

.cui-dialog-title {
  font-size: 1.125rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0 0 8px 0;
  line-height: 1.5;
}

.cui-dialog-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-dialog-footer {
  display: flex;
  flex-direction: column-reverse;
  gap: 8px;
}

@media (min-width: 640px) {
  .cui-dialog-footer {
    flex-direction: row;
    justify-content: flex-end;
  }
}`

export default function AlertDialogDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

