import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'calendar',
  name: 'Calendar',
  description: 'A date field component that allows users to enter and edit date',
}

const html = `<div class="cui-calendar">
  <div class="cui-calendar-header">
    <div class="cui-calendar-nav">
      <button class="cui-calendar-nav-button" aria-label="Previous month">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 4L6 8L10 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
      <div class="cui-calendar-month-year">
        <div class="cui-calendar-month">
          Nov
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <div class="cui-calendar-year">
          2025
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
      </div>
      <button class="cui-calendar-nav-button" aria-label="Next month">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
    </div>
  </div>
  <div class="cui-calendar-body">
    <div class="cui-calendar-weekdays">
      <div class="cui-calendar-weekday">Su</div>
      <div class="cui-calendar-weekday">Mo</div>
      <div class="cui-calendar-weekday">Tu</div>
      <div class="cui-calendar-weekday">We</div>
      <div class="cui-calendar-weekday">Th</div>
      <div class="cui-calendar-weekday">Fr</div>
      <div class="cui-calendar-weekday">Sa</div>
    </div>
    <div class="cui-calendar-days">
      <button class="cui-calendar-day cui-calendar-day--outside">26</button>
      <button class="cui-calendar-day cui-calendar-day--outside">27</button>
      <button class="cui-calendar-day cui-calendar-day--outside">28</button>
      <button class="cui-calendar-day cui-calendar-day--outside">29</button>
      <button class="cui-calendar-day cui-calendar-day--outside">30</button>
      <button class="cui-calendar-day cui-calendar-day--outside">31</button>
      <button class="cui-calendar-day cui-calendar-day--selected">1</button>
      <button class="cui-calendar-day">2</button>
      <button class="cui-calendar-day">3</button>
      <button class="cui-calendar-day">4</button>
      <button class="cui-calendar-day">5</button>
      <button class="cui-calendar-day">6</button>
      <button class="cui-calendar-day">7</button>
      <button class="cui-calendar-day">8</button>
      <button class="cui-calendar-day">9</button>
      <button class="cui-calendar-day">10</button>
      <button class="cui-calendar-day">11</button>
      <button class="cui-calendar-day">12</button>
      <button class="cui-calendar-day">13</button>
      <button class="cui-calendar-day">14</button>
      <button class="cui-calendar-day">15</button>
      <button class="cui-calendar-day">16</button>
      <button class="cui-calendar-day">17</button>
      <button class="cui-calendar-day">18</button>
      <button class="cui-calendar-day">19</button>
      <button class="cui-calendar-day">20</button>
      <button class="cui-calendar-day">21</button>
      <button class="cui-calendar-day">22</button>
      <button class="cui-calendar-day">23</button>
      <button class="cui-calendar-day">24</button>
      <button class="cui-calendar-day">25</button>
      <button class="cui-calendar-day">26</button>
      <button class="cui-calendar-day">27</button>
      <button class="cui-calendar-day">28</button>
      <button class="cui-calendar-day">29</button>
      <button class="cui-calendar-day">30</button>
      <button class="cui-calendar-day cui-calendar-day--outside">1</button>
      <button class="cui-calendar-day cui-calendar-day--outside">2</button>
      <button class="cui-calendar-day cui-calendar-day--outside">3</button>
      <button class="cui-calendar-day cui-calendar-day--outside">4</button>
      <button class="cui-calendar-day cui-calendar-day--outside">5</button>
      <button class="cui-calendar-day cui-calendar-day--outside">6</button>
    </div>
  </div>
</div>`

const css = `.cui-calendar {
  width: 100%;
  max-width: 224px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  padding: 12px;
}

.cui-calendar-header {
  margin-bottom: 12px;
}

.cui-calendar-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.cui-calendar-nav-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  border-radius: calc(var(--radius) - 2px);
  border: none;
  background: transparent;
  color: hsl(var(--foreground));
  cursor: pointer;
  transition: background-color 0.15s ease;
}

.cui-calendar-nav-button:hover {
  background: hsl(var(--muted));
}

.cui-calendar-month-year {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1;
  justify-content: center;
}

.cui-calendar-month,
.cui-calendar-year {
  display: flex;
  align-items: center;
  gap: 2px;
  font-size: 0.8125rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  cursor: pointer;
  padding: 2px 6px;
  border-radius: calc(var(--radius) - 2px);
  transition: background-color 0.15s ease;
}

.cui-calendar-month:hover,
.cui-calendar-year:hover {
  background: hsl(var(--muted));
}

.cui-calendar-month svg,
.cui-calendar-year svg {
  width: 10px;
  height: 10px;
  color: hsl(var(--muted-foreground));
}

.cui-calendar-body {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cui-calendar-weekdays {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 0;
}

.cui-calendar-weekday {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.6875rem;
  font-weight: 500;
  color: hsl(var(--muted-foreground));
  height: 28px;
}

.cui-calendar-days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 0;
}

.cui-calendar-day {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 1;
  min-width: 0;
  font-size: 0.8125rem;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) - 2px);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
  position: relative;
}

.cui-calendar-day:hover {
  background: hsl(var(--muted));
}

.cui-calendar-day--selected {
  background: hsl(var(--primary));
  color: hsl(var(--primary-foreground));
  font-weight: 500;
}

.cui-calendar-day--selected:hover {
  background: hsl(var(--primary));
  opacity: 0.9;
}

.cui-calendar-day--outside {
  color: hsl(var(--muted-foreground));
  opacity: 0.5;
}

.cui-calendar-day--outside:hover {
  background: hsl(var(--muted));
}`

export default function CalendarDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

