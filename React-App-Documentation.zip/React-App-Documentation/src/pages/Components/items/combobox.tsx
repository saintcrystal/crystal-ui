import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'combobox',
  name: 'Combobox',
  description: 'Autocomplete input and command palette with a list of suggestions',
}

const html = `<div class="cui-combobox-wrapper">
  <input type="checkbox" id="cui-combobox-toggle" class="cui-combobox-checkbox" />
  <div class="cui-combobox">
    <label for="cui-combobox-toggle" class="cui-combobox-trigger">
      <span class="cui-combobox-value">Remix</span>
      <svg class="cui-combobox-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </label>
    <div class="cui-combobox-popover">
      <div class="cui-combobox-search">
        <svg class="cui-combobox-search-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="7" cy="7" r="4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M11 11L14 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <input type="text" class="cui-combobox-search-input" placeholder="Search framework..." />
      </div>
      <div class="cui-combobox-list">
        <button class="cui-combobox-item">
          <span>Next.js</span>
        </button>
        <button class="cui-combobox-item">
          <span>SvelteKit</span>
        </button>
        <button class="cui-combobox-item">
          <span>Nuxt.js</span>
        </button>
        <button class="cui-combobox-item cui-combobox-item--selected">
          <span>Remix</span>
          <svg class="cui-combobox-check" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13 4L6 11L3 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>
        <button class="cui-combobox-item">
          <span>Astro</span>
        </button>
      </div>
    </div>
  </div>
  <label for="cui-combobox-toggle" class="cui-combobox-overlay"></label>
</div>`

const css = `.cui-combobox-wrapper {
  position: relative;
  display: inline-block;
  width: 100%;
  max-width: 320px;
}

.cui-combobox-checkbox {
  display: none;
}

.cui-combobox {
  position: relative;
  width: 100%;
}

.cui-combobox-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 40px;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  cursor: pointer;
  transition: border-color 0.15s ease;
}

.cui-combobox-trigger:hover {
  border-color: hsl(var(--input));
}

.cui-combobox-value {
  flex: 1;
  text-align: left;
  color: hsl(var(--foreground));
}

.cui-combobox-chevron {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
  transition: transform 0.15s ease;
}

.cui-combobox-checkbox:checked ~ .cui-combobox .cui-combobox-chevron {
  transform: rotate(180deg);
}

.cui-combobox-popover {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  z-index: 50;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
  overflow: hidden;
}

.cui-combobox-checkbox:checked ~ .cui-combobox .cui-combobox-popover {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-combobox-search {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px;
  border-bottom: 1px solid hsl(var(--border));
}

.cui-combobox-search-icon {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
}

.cui-combobox-search-input {
  flex: 1;
  height: 32px;
  padding: 0 8px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  outline: none;
}

.cui-combobox-search-input::placeholder {
  color: hsl(var(--muted-foreground));
}

.cui-combobox-list {
  display: flex;
  flex-direction: column;
  padding: 4px;
  max-height: 240px;
  overflow-y: auto;
}

.cui-combobox-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 8px 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) - 2px);
  cursor: pointer;
  text-align: left;
  transition: background-color 0.15s ease;
}

.cui-combobox-item:hover {
  background: hsl(var(--muted));
}

.cui-combobox-item--selected {
  background: hsl(var(--muted));
}

.cui-combobox-check {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--primary));
}

.cui-combobox-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
}

.cui-combobox-checkbox:checked ~ .cui-combobox-overlay {
  opacity: 1;
  pointer-events: auto;
}`

export default function ComboboxDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

