import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'textarea',
  name: 'Textarea',
  description: 'Displays a form textarea or a component that looks like a textarea',
}

const html = `<div style="display: flex; flex-direction: column; gap: 24px; max-width: 400px;">
  <!-- Basic Textarea -->
  <div class="cui-textarea-field">
    <textarea class="cui-textarea" placeholder="Type your message here."></textarea>
  </div>

  <!-- Textarea with Label -->
  <div class="cui-textarea-field">
    <label class="cui-label" for="message-textarea">Message</label>
    <textarea id="message-textarea" class="cui-textarea" placeholder="Type your message here."></textarea>
  </div>

  <!-- Textarea with Label and Description -->
  <div class="cui-textarea-field">
    <label class="cui-label" for="bio-textarea">Bio</label>
    <textarea id="bio-textarea" class="cui-textarea" placeholder="Tell us a little bit about yourself."></textarea>
    <p class="cui-textarea-description">You can @mention other users and organizations.</p>
  </div>

  <!-- Textarea with Value -->
  <div class="cui-textarea-field">
    <label class="cui-label" for="filled-textarea">Message</label>
    <textarea id="filled-textarea" class="cui-textarea">This is a longer text area that demonstrates how content looks when it's already filled in.</textarea>
  </div>

  <!-- Disabled Textarea -->
  <div class="cui-textarea-field">
    <label class="cui-label" for="disabled-textarea">Disabled</label>
    <textarea id="disabled-textarea" class="cui-textarea" placeholder="Disabled textarea" disabled></textarea>
  </div>

  <!-- Textarea with Error -->
  <div class="cui-textarea-field">
    <label class="cui-label" for="error-textarea">Email</label>
    <textarea id="error-textarea" class="cui-textarea cui-textarea--error" placeholder="Type your message here.">This is an invalid message.</textarea>
    <p class="cui-textarea-error">Your message is too short.</p>
  </div>
</div>`

const css = `.cui-textarea-field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cui-textarea {
  width: 100%;
  min-height: 80px;
  padding: 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
  outline: none;
  resize: vertical;
  font-family: inherit;
  line-height: 1.5;
}

.cui-textarea:focus {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-textarea::placeholder {
  color: hsl(var(--muted-foreground));
}

.cui-textarea:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.cui-textarea--error {
  border-color: hsl(0 72% 51%);
}

.cui-textarea--error:focus {
  border-color: hsl(0 72% 51%);
  box-shadow: 0 0 0 2px hsl(0 72% 51% / 0.1);
}

.cui-label {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-textarea-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-textarea-error {
  font-size: 0.875rem;
  color: hsl(0 72% 51%);
  margin: 0;
  line-height: 1.5;
}`

export default function TextareaDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

