import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'badge',
  name: 'Badge',
  description: 'Displays a badge or a component that looks like a badge',
}

const html = `<div class="cui-badge">Badge</div>
<div class="cui-badge cui-badge--secondary" style="margin-left: 8px;">Secondary</div>
<div class="cui-badge cui-badge--destructive" style="margin-left: 8px;">Destructive</div>
<div class="cui-badge cui-badge--outline" style="margin-left: 8px;">Outline</div>`

const css = `.cui-badge {
  display: inline-flex;
  align-items: center;
  border-radius: var(--radius);
  padding: 2px 10px;
  font-size: 0.75rem;
  font-weight: 600;
  line-height: 1.5;
  transition: opacity 0.15s ease;
  background: hsl(var(--primary));
  color: hsl(var(--primary-foreground));
}

.cui-badge--secondary {
  background: hsl(var(--muted));
  color: hsl(var(--muted-foreground));
}

.cui-badge--destructive {
  background: hsl(0 72% 51%);
  color: white;
}

.dark .cui-badge--destructive {
  background: hsl(0 55% 50%);
}

.cui-badge--outline {
  background: transparent;
  border: 1px solid hsl(var(--input));
  color: hsl(var(--foreground));
}`

export default function BadgeDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

