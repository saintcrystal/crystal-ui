import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'dialog',
  name: 'Dialog',
  description: 'A window overlaid on either the primary window or another dialog window, rendering the content underneath inert',
}

const html = `<input type="checkbox" id="cui-dialog-modal-trigger" class="cui-dialog-modal-checkbox" />
<div class="cui-dialog-modal-overlay">
  <label for="cui-dialog-modal-trigger" class="cui-dialog-modal-overlay-bg"></label>
  <div class="cui-dialog-modal-content">
    <div class="cui-dialog-modal-header">
      <div class="cui-dialog-modal-header-content">
        <h2 class="cui-dialog-modal-title">Edit profile</h2>
        <p class="cui-dialog-modal-description">
          Make changes to your profile here. Click save when you're done.
        </p>
      </div>
      <label for="cui-dialog-modal-trigger" class="cui-dialog-modal-close">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </label>
    </div>
    <div class="cui-dialog-modal-body">
      <div class="cui-form-field">
        <label class="cui-label" for="dialog-name">Name</label>
        <input type="text" id="dialog-name" class="cui-input" value="Pedro Duarte" />
      </div>
      <div class="cui-form-field">
        <label class="cui-label" for="dialog-username">Username</label>
        <input type="text" id="dialog-username" class="cui-input" value="@peduarte" />
      </div>
    </div>
    <div class="cui-dialog-modal-footer">
      <label for="cui-dialog-modal-trigger" class="cui-btn cui-btn--outline">Cancel</label>
      <label for="cui-dialog-modal-trigger" class="cui-btn cui-btn--primary">Save changes</label>
    </div>
  </div>
</div>
<label for="cui-dialog-modal-trigger" class="cui-btn cui-btn--primary">Open Dialog</label>`

const css = `.cui-dialog-modal-checkbox {
  display: none;
}

.cui-dialog-modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 50;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
}

#cui-dialog-modal-trigger:checked ~ .cui-dialog-modal-overlay {
  opacity: 1;
  pointer-events: auto;
}

.cui-dialog-modal-overlay-bg {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  cursor: pointer;
}

.cui-dialog-modal-content {
  position: relative;
  z-index: 1;
  max-width: 29rem;
  width: 100%;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: 16px;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 24px;
  opacity: 0;
  transform: scale(0.95) translateY(-10px);
  transition: opacity 0.15s ease, transform 0.15s ease;
}

#cui-dialog-modal-trigger:checked ~ .cui-dialog-modal-overlay .cui-dialog-modal-content {
  opacity: 1;
  transform: scale(1) translateY(0);
}

.cui-dialog-modal-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 24px;
}

.cui-dialog-modal-header-content {
  flex: 1;
}

.cui-dialog-modal-title {
  font-size: 1.125rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0 0 8px 0;
  line-height: 1.5;
}

.cui-dialog-modal-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-dialog-modal-close {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  margin-left: 16px;
  margin-top: -4px;
  margin-right: -4px;
  border-radius: calc(var(--radius) - 2px);
  color: hsl(var(--muted-foreground));
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.cui-dialog-modal-close:hover {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-dialog-modal-close svg {
  width: 16px;
  height: 16px;
}

.cui-dialog-modal-body {
  margin-bottom: 24px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.cui-dialog-modal-footer {
  display: flex;
  flex-direction: column-reverse;
  gap: 8px;
}

@media (min-width: 640px) {
  .cui-dialog-modal-footer {
    flex-direction: row;
    justify-content: flex-end;
  }
}`

export default function DialogDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

