import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'data-table',
  name: 'Data Table',
  description: 'Powerful table and datagrids built using TanStack Table',
}

const html = `<div class="cui-data-table-wrapper">
  <input type="checkbox" id="cui-data-table-columns-toggle" class="cui-data-table-columns-checkbox" />
  <input type="checkbox" id="cui-data-table-action-1" class="cui-data-table-action-checkbox" />
  <input type="checkbox" id="cui-data-table-action-2" class="cui-data-table-action-checkbox" />
  <input type="checkbox" id="cui-data-table-action-3" class="cui-data-table-action-checkbox" />
  <input type="checkbox" id="cui-data-table-action-4" class="cui-data-table-action-checkbox" />
  <input type="checkbox" id="cui-data-table-action-5" class="cui-data-table-action-checkbox" />
  <div class="cui-data-table">
    <div class="cui-data-table-header">
      <input type="text" class="cui-data-table-filter" placeholder="Filter emails..." />
      <div class="cui-data-table-header-actions">
        <label for="cui-data-table-columns-toggle" class="cui-btn cui-btn--outline">
          Columns
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left: 8px;">
            <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </label>
        <div class="cui-data-table-columns-dropdown">
        <div class="cui-data-table-columns-content">
          <label class="cui-data-table-column-item">
            <input type="checkbox" class="cui-checkbox-input" checked />
            <span class="cui-checkbox">
              <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </span>
            <span>Status</span>
          </label>
          <label class="cui-data-table-column-item">
            <input type="checkbox" class="cui-checkbox-input" checked />
            <span class="cui-checkbox">
              <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </span>
            <span>Email</span>
          </label>
          <label class="cui-data-table-column-item">
            <input type="checkbox" class="cui-checkbox-input" checked />
            <span class="cui-checkbox">
              <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </span>
            <span>Amount</span>
          </label>
        </div>
      </div>
    </div>
  </div>
  <div class="cui-data-table-container">
    <table class="cui-table">
      <thead>
        <tr>
          <th class="cui-table-header-cell" style="width: 48px;">
            <label class="cui-checkbox-label" style="justify-content: center;">
              <input type="checkbox" class="cui-checkbox-input" />
              <span class="cui-checkbox">
                <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
            </label>
          </th>
          <th class="cui-table-header-cell">Status</th>
          <th class="cui-table-header-cell cui-table-header-cell--sortable">
            Email
            <svg class="cui-table-sort-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </th>
          <th class="cui-table-header-cell" style="text-align: right;">Amount</th>
          <th class="cui-table-header-cell" style="width: 48px;"></th>
        </tr>
      </thead>
      <tbody>
        <tr class="cui-table-row cui-table-row-1">
          <td class="cui-table-cell">
            <label class="cui-checkbox-label" style="justify-content: center;">
              <input type="checkbox" class="cui-checkbox-input" />
              <span class="cui-checkbox">
                <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
            </label>
          </td>
          <td class="cui-table-cell">Success</td>
          <td class="cui-table-cell">ken99@example.com</td>
          <td class="cui-table-cell" style="text-align: right;">$316.00</td>
          <td class="cui-table-cell" style="text-align: center;">
            <div style="position: relative; display: inline-block;">
              <label for="cui-data-table-action-1" class="cui-table-action-button">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="4" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="8" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="12" cy="8" r="1.5" fill="currentColor"/>
                </svg>
              </label>
              <div class="cui-table-action-dropdown cui-table-action-dropdown-1">
              <div class="cui-table-action-menu">
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 2V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M2 8H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Edit</span>
                </a>
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 4L14 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6 8H10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Copy</span>
                </a>
                <div class="cui-table-action-menu-separator"></div>
                <a href="#" class="cui-table-action-menu-item cui-table-action-menu-item--destructive">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Delete</span>
                </a>
              </div>
            </div>
            </div>
          </td>
        </tr>
        <tr class="cui-table-row cui-table-row-2">
          <td class="cui-table-cell">
            <label class="cui-checkbox-label" style="justify-content: center;">
              <input type="checkbox" class="cui-checkbox-input" />
              <span class="cui-checkbox">
                <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
            </label>
          </td>
          <td class="cui-table-cell">Processing</td>
          <td class="cui-table-cell">abe45@example.com</td>
          <td class="cui-table-cell" style="text-align: right;">$242.00</td>
          <td class="cui-table-cell" style="text-align: center;">
            <div style="position: relative; display: inline-block;">
              <label for="cui-data-table-action-2" class="cui-table-action-button">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="4" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="8" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="12" cy="8" r="1.5" fill="currentColor"/>
                </svg>
              </label>
              <div class="cui-table-action-dropdown cui-table-action-dropdown-2">
              <div class="cui-table-action-menu">
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 2V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M2 8H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Edit</span>
                </a>
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 4L14 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6 8H10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Copy</span>
                </a>
                <div class="cui-table-action-menu-separator"></div>
                <a href="#" class="cui-table-action-menu-item cui-table-action-menu-item--destructive">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Delete</span>
                </a>
              </div>
            </div>
            </div>
          </td>
        </tr>
        <tr class="cui-table-row cui-table-row-3">
          <td class="cui-table-cell">
            <label class="cui-checkbox-label" style="justify-content: center;">
              <input type="checkbox" class="cui-checkbox-input" />
              <span class="cui-checkbox">
                <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
            </label>
          </td>
          <td class="cui-table-cell">Success</td>
          <td class="cui-table-cell">monserrat44@example.com</td>
          <td class="cui-table-cell" style="text-align: right;">$100.00</td>
          <td class="cui-table-cell" style="text-align: center;">
            <div style="position: relative; display: inline-block;">
              <label for="cui-data-table-action-3" class="cui-table-action-button">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="4" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="8" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="12" cy="8" r="1.5" fill="currentColor"/>
                </svg>
              </label>
              <div class="cui-table-action-dropdown cui-table-action-dropdown-3">
              <div class="cui-table-action-menu">
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 2V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M2 8H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Edit</span>
                </a>
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 4L14 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6 8H10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Copy</span>
                </a>
                <div class="cui-table-action-menu-separator"></div>
                <a href="#" class="cui-table-action-menu-item cui-table-action-menu-item--destructive">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Delete</span>
                </a>
              </div>
            </div>
            </div>
          </td>
        </tr>
        <tr class="cui-table-row cui-table-row-4">
          <td class="cui-table-cell">
            <label class="cui-checkbox-label" style="justify-content: center;">
              <input type="checkbox" class="cui-checkbox-input" />
              <span class="cui-checkbox">
                <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
            </label>
          </td>
          <td class="cui-table-cell">Failed</td>
          <td class="cui-table-cell">silas22@example.com</td>
          <td class="cui-table-cell" style="text-align: right;">$87.00</td>
          <td class="cui-table-cell" style="text-align: center;">
            <div style="position: relative; display: inline-block;">
              <label for="cui-data-table-action-4" class="cui-table-action-button">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="4" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="8" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="12" cy="8" r="1.5" fill="currentColor"/>
                </svg>
              </label>
              <div class="cui-table-action-dropdown cui-table-action-dropdown-4">
              <div class="cui-table-action-menu">
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 2V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M2 8H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Edit</span>
                </a>
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 4L14 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6 8H10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Copy</span>
                </a>
                <div class="cui-table-action-menu-separator"></div>
                <a href="#" class="cui-table-action-menu-item cui-table-action-menu-item--destructive">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Delete</span>
                </a>
              </div>
            </div>
            </div>
          </td>
        </tr>
        <tr class="cui-table-row cui-table-row-5">
          <td class="cui-table-cell">
            <label class="cui-checkbox-label" style="justify-content: center;">
              <input type="checkbox" class="cui-checkbox-input" />
              <span class="cui-checkbox">
                <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
            </label>
          </td>
          <td class="cui-table-cell">Success</td>
          <td class="cui-table-cell">carmella@example.com</td>
          <td class="cui-table-cell" style="text-align: right;">$367.00</td>
          <td class="cui-table-cell" style="text-align: center;">
            <div style="position: relative; display: inline-block;">
              <label for="cui-data-table-action-5" class="cui-table-action-button">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="4" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="8" cy="8" r="1.5" fill="currentColor"/>
                  <circle cx="12" cy="8" r="1.5" fill="currentColor"/>
                </svg>
              </label>
              <div class="cui-table-action-dropdown cui-table-action-dropdown-5">
              <div class="cui-table-action-menu">
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 2V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M2 8H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Edit</span>
                </a>
                <a href="#" class="cui-table-action-menu-item">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 4L14 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M6 8H10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Copy</span>
                </a>
                <div class="cui-table-action-menu-separator"></div>
                <a href="#" class="cui-table-action-menu-item cui-table-action-menu-item--destructive">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                  </svg>
                  <span>Delete</span>
                </a>
              </div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div class="cui-data-table-footer">
    <div class="cui-data-table-footer-info">0 of 5 row(s) selected.</div>
    <div class="cui-data-table-footer-actions">
      <button class="cui-btn cui-btn--outline">Previous</button>
      <button class="cui-btn cui-btn--outline" style="margin-left: 8px;">Next</button>
    </div>
  </div>
  </div>
  <label for="cui-data-table-columns-toggle" class="cui-data-table-columns-overlay"></label>
  <label for="cui-data-table-action-1" class="cui-data-table-action-overlay cui-data-table-action-overlay-1"></label>
  <label for="cui-data-table-action-2" class="cui-data-table-action-overlay cui-data-table-action-overlay-2"></label>
  <label for="cui-data-table-action-3" class="cui-data-table-action-overlay cui-data-table-action-overlay-3"></label>
  <label for="cui-data-table-action-4" class="cui-data-table-action-overlay cui-data-table-action-overlay-4"></label>
  <label for="cui-data-table-action-5" class="cui-data-table-action-overlay cui-data-table-action-overlay-5"></label>
</div>`

const css = `.cui-data-table-wrapper {
  position: relative;
}

.cui-data-table-columns-checkbox {
  display: none;
}

.cui-data-table {
  width: 100%;
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  overflow: hidden;
}

.cui-data-table-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  border-bottom: 1px solid hsl(var(--border));
}

.cui-data-table-filter {
  width: 100%;
  max-width: 300px;
  height: 40px;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
  outline: none;
}

.cui-data-table-filter:focus {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-data-table-filter::placeholder {
  color: hsl(var(--muted-foreground));
}

.cui-data-table-header-actions {
  position: relative;
}

.cui-data-table-columns-checkbox {
  display: none;
}

.cui-data-table-columns-dropdown {
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  z-index: 50;
  min-width: 200px;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
}

.cui-data-table-columns-checkbox:checked ~ .cui-data-table .cui-data-table-header-actions .cui-data-table-columns-dropdown {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-data-table-columns-content {
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 4px;
  display: flex;
  flex-direction: column;
}

.cui-data-table-column-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 12px;
  cursor: pointer;
  border-radius: calc(var(--radius) - 2px);
  transition: background-color 0.15s ease;
}

.cui-data-table-column-item:hover {
  background: hsl(var(--muted));
}

.cui-data-table-container {
  overflow-x: auto;
}

.cui-table {
  width: 100%;
  border-collapse: collapse;
}

.cui-table-header-cell {
  padding: 12px 16px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--muted-foreground));
  text-align: left;
  background: hsl(var(--muted));
  border-bottom: 1px solid hsl(var(--border));
}

.cui-table-header-cell--sortable {
  cursor: pointer;
  user-select: none;
}

.cui-table-sort-icon {
  display: inline-block;
  margin-left: 8px;
  width: 16px;
  height: 16px;
  vertical-align: middle;
  color: hsl(var(--muted-foreground));
}

.cui-table-row {
  border-bottom: 1px solid hsl(var(--border));
  transition: background-color 0.15s ease;
}

.cui-table-row:hover {
  background: hsl(var(--muted));
}

.cui-table-cell {
  padding: 12px 16px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  text-align: left;
}

.cui-data-table-action-checkbox {
  display: none;
}

.cui-table-action-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  padding: 0;
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) - 2px);
  color: hsl(var(--muted-foreground));
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.cui-table-action-button:hover {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-table-action-dropdown {
  position: absolute;
  top: calc(100% + 4px);
  right: 0;
  z-index: 9999;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
}

#cui-data-table-action-1:checked ~ .cui-data-table .cui-table-row-1 .cui-table-action-dropdown-1,
#cui-data-table-action-2:checked ~ .cui-data-table .cui-table-row-2 .cui-table-action-dropdown-2,
#cui-data-table-action-3:checked ~ .cui-data-table .cui-table-row-3 .cui-table-action-dropdown-3,
#cui-data-table-action-4:checked ~ .cui-data-table .cui-table-row-4 .cui-table-action-dropdown-4,
#cui-data-table-action-5:checked ~ .cui-data-table .cui-table-row-5 .cui-table-action-dropdown-5 {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-table-action-menu {
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 4px;
  display: flex;
  flex-direction: column;
  min-width: 160px;
}

.cui-table-action-menu-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  text-decoration: none;
  border-radius: calc(var(--radius) - 2px);
  transition: background-color 0.15s ease;
  cursor: pointer;
}

.cui-table-action-menu-item:hover {
  background: hsl(var(--muted));
}

.cui-table-action-menu-item svg {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
}

.cui-table-action-menu-item--destructive {
  color: hsl(0 72% 51%);
}

.cui-table-action-menu-item--destructive svg {
  color: hsl(0 72% 51%);
}

.cui-table-action-menu-item--destructive:hover {
  background: hsl(0 72% 51% / 0.1);
}

.cui-table-action-menu-separator {
  height: 1px;
  background: hsl(var(--border));
  margin: 4px 0;
}

.cui-data-table-action-overlay {
  position: fixed;
  inset: 0;
  z-index: 9998;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
  cursor: default;
}

#cui-data-table-action-1:checked ~ .cui-data-table-action-overlay-1,
#cui-data-table-action-2:checked ~ .cui-data-table-action-overlay-2,
#cui-data-table-action-3:checked ~ .cui-data-table-action-overlay-3,
#cui-data-table-action-4:checked ~ .cui-data-table-action-overlay-4,
#cui-data-table-action-5:checked ~ .cui-data-table-action-overlay-5 {
  opacity: 1;
  pointer-events: auto;
}

.cui-data-table-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  border-top: 1px solid hsl(var(--border));
}

.cui-data-table-footer-info {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
}

.cui-data-table-footer-actions {
  display: flex;
  align-items: center;
}

.cui-data-table-columns-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
}

.cui-data-table-columns-checkbox:checked ~ .cui-data-table-columns-overlay {
  opacity: 1;
  pointer-events: auto;
}`

export default function DataTableDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

