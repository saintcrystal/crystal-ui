import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'scroll-area',
  name: 'Scroll Area',
  description: 'Augments native scroll functionality for custom, cross-browser styling',
}

const html = `<div class="cui-scroll-area">
  <div class="cui-scroll-area-viewport">
    <div class="cui-scroll-area-content">
      <div class="cui-scroll-area-heading">Tags</div>
      <div class="cui-scroll-area-list">
        <div class="cui-scroll-area-item">v1.2.0-beta.50</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.49</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.48</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.47</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.46</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.45</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.44</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.43</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.42</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.41</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.40</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.39</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.38</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.37</div>
        <div class="cui-scroll-area-item">v1.2.0-beta.36</div>
      </div>
    </div>
  </div>
</div>`

const css = `.cui-scroll-area {
  width: 100%;
  max-width: 300px;
  position: relative;
  overflow: hidden;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1);
}

.cui-scroll-area-viewport {
  width: 100%;
  height: 200px;
  overflow-y: scroll;
  overflow-x: hidden;
  scrollbar-width: thin;
  scrollbar-color: hsl(var(--border)) transparent;
}

.cui-scroll-area-viewport::-webkit-scrollbar {
  width: 8px;
}

.cui-scroll-area-viewport::-webkit-scrollbar-track {
  background: transparent;
}

.cui-scroll-area-viewport::-webkit-scrollbar-thumb {
  background: hsl(var(--border));
  border-radius: 4px;
  border: 2px solid transparent;
  background-clip: padding-box;
}

.cui-scroll-area-viewport::-webkit-scrollbar-thumb:hover {
  background: hsl(var(--muted-foreground));
  background-clip: padding-box;
}

.cui-scroll-area-content {
  padding: 16px;
}

.cui-scroll-area-heading {
  font-size: 0.875rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin-bottom: 12px;
}

.cui-scroll-area-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cui-scroll-area-item {
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  line-height: 1.5;
}`

export default function ScrollAreaDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

