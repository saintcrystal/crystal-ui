import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'breadcrumb',
  name: 'Breadcrumb',
  description: 'Displays the path to the current resource using a hierarchy of links',
}

const html = `<nav class="cui-breadcrumb" aria-label="Breadcrumb">
  <ol class="cui-breadcrumb-list">
    <li class="cui-breadcrumb-item">
      <a href="#" class="cui-breadcrumb-link">Home</a>
    </li>
    <li class="cui-breadcrumb-separator">/</li>
    <li class="cui-breadcrumb-item">
      <a href="#" class="cui-breadcrumb-link">Components</a>
    </li>
    <li class="cui-breadcrumb-separator">/</li>
    <li class="cui-breadcrumb-item">
      <span class="cui-breadcrumb-page">Breadcrumb</span>
    </li>
  </ol>
</nav>

<nav class="cui-breadcrumb" aria-label="Breadcrumb" style="margin-top: 16px;">
  <ol class="cui-breadcrumb-list">
    <li class="cui-breadcrumb-item">
      <a href="#" class="cui-breadcrumb-link">Home</a>
    </li>
    <li class="cui-breadcrumb-separator">/</li>
    <li class="cui-breadcrumb-item">
      <span class="cui-breadcrumb-ellipsis">...</span>
    </li>
    <li class="cui-breadcrumb-separator">/</li>
    <li class="cui-breadcrumb-item">
      <a href="#" class="cui-breadcrumb-link">Components</a>
    </li>
    <li class="cui-breadcrumb-separator">/</li>
    <li class="cui-breadcrumb-item">
      <span class="cui-breadcrumb-page">Breadcrumb</span>
    </li>
  </ol>
</nav>

<nav class="cui-breadcrumb" aria-label="Breadcrumb" style="margin-top: 16px;">
  <ol class="cui-breadcrumb-list">
    <li class="cui-breadcrumb-item">
      <a href="#" class="cui-breadcrumb-link">Home</a>
    </li>
    <li class="cui-breadcrumb-separator cui-breadcrumb-separator--chevron">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </li>
    <li class="cui-breadcrumb-item">
      <a href="#" class="cui-breadcrumb-link">Components</a>
    </li>
    <li class="cui-breadcrumb-separator cui-breadcrumb-separator--chevron">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </li>
    <li class="cui-breadcrumb-item">
      <span class="cui-breadcrumb-page">Breadcrumb</span>
    </li>
  </ol>
</nav>`

const css = `.cui-breadcrumb {
  display: flex;
  align-items: center;
}

.cui-breadcrumb-list {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  list-style: none;
  padding: 0;
  margin: 0;
}

.cui-breadcrumb-item {
  display: inline-flex;
  align-items: center;
}

.cui-breadcrumb-link {
  transition: color 0.15s ease;
  color: hsl(var(--muted-foreground));
  text-decoration: none;
}

.cui-breadcrumb-link:hover {
  color: hsl(var(--foreground));
}

.cui-breadcrumb-page {
  color: hsl(var(--foreground));
  font-weight: 500;
}

.cui-breadcrumb-separator {
  color: hsl(var(--muted-foreground));
  display: inline-flex;
  align-items: center;
  margin: 0 4px;
}

.cui-breadcrumb-separator--chevron {
  margin: 0 2px;
  width: 16px;
  height: 16px;
}

.cui-breadcrumb-ellipsis {
  display: flex;
  height: 16px;
  width: 16px;
  align-items: center;
  justify-content: center;
  color: hsl(var(--muted-foreground));
}

.cui-breadcrumb-ellipsis::before {
  content: "…";
  font-size: 1rem;
  line-height: 1;
}`

export default function BreadcrumbDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

