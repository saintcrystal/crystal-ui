import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'toggle-group',
  name: 'Toggle Group',
  description: 'A set of two-state buttons that can be toggled on or off',
}

const html = `<div style="display: flex; gap: 8px;">
  <input type="checkbox" id="toggle-star" class="cui-toggle-input" checked />
  <label for="toggle-star" class="cui-toggle-item">
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 1L9.854 6.146L15 8L9.854 9.854L8 15L6.146 9.854L1 8L6.146 6.146L8 1Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="currentColor"/>
    </svg>
    <span>Star</span>
  </label>
  <input type="checkbox" id="toggle-heart" class="cui-toggle-input" />
  <label for="toggle-heart" class="cui-toggle-item">
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 2.5C6.5 1.5 4 2 3 4C2 6 4 8 8 11C12 8 14 6 13 4C12 2 9.5 1.5 8 2.5Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <span>Heart</span>
  </label>
  <input type="checkbox" id="toggle-bookmark" class="cui-toggle-input" />
  <label for="toggle-bookmark" class="cui-toggle-item">
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 2H12V13L8 10L4 13V2Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <span>Bookmark</span>
  </label>
</div>`

const css = `.cui-toggle-input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}

.cui-toggle-item {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 32px;
  padding: 0 12px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  background: white;
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  cursor: pointer;
  transition: all 0.15s ease;
  user-select: none;
  white-space: nowrap;
}

.dark .cui-toggle-item {
  background: hsl(var(--background));
}

.cui-toggle-item svg {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
  transition: color 0.15s ease;
}

.cui-toggle-input:checked + .cui-toggle-item svg {
  color: hsl(48 100% 50%);
}

.cui-toggle-input:focus-visible + .cui-toggle-item {
  outline: 2px solid hsl(var(--primary));
  outline-offset: 2px;
}

.cui-toggle-input:disabled + .cui-toggle-item {
  opacity: 0.5;
  cursor: not-allowed;
}`

export default function ToggleGroupDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

