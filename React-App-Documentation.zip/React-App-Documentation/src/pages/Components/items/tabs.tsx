import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'tabs',
  name: 'Tabs',
  description: 'A set of layered sections of content—known as tab panels—that are displayed one at a time',
}

const html = `<div class="cui-tabs">
  <input type="radio" name="cui-tabs-group" id="cui-tab-account" class="cui-tabs-radio" checked />
  <input type="radio" name="cui-tabs-group" id="cui-tab-password" class="cui-tabs-radio" />
  
  <div class="cui-tabs-list">
    <label for="cui-tab-account" class="cui-tabs-trigger">Account</label>
    <label for="cui-tab-password" class="cui-tabs-trigger">Password</label>
  </div>
  
  <div class="cui-tabs-content-wrapper">
    <div class="cui-tabs-content" data-tab="account">
      <div class="cui-tabs-content-inner">
        <h3 class="cui-tabs-content-title">Account</h3>
        <p class="cui-tabs-content-description">Make changes to your account here. Click save when you're done.</p>
        <div class="cui-form-field" style="margin-top: 24px;">
          <label class="cui-label" for="account-name">Name</label>
          <input type="text" id="account-name" class="cui-input" placeholder="Pedro Duarte" />
        </div>
        <div class="cui-form-field" style="margin-top: 16px;">
          <label class="cui-label" for="account-username">Username</label>
          <input type="text" id="account-username" class="cui-input" placeholder="@peduarte" />
        </div>
        <button class="cui-btn cui-btn--primary" style="margin-top: 24px;">Save changes</button>
      </div>
    </div>
    
    <div class="cui-tabs-content" data-tab="password">
      <div class="cui-tabs-content-inner">
        <h3 class="cui-tabs-content-title">Password</h3>
        <p class="cui-tabs-content-description">Change your password here. After saving, you'll be logged out.</p>
        <div class="cui-form-field" style="margin-top: 24px;">
          <label class="cui-label" for="password-current">Current password</label>
          <input type="password" id="password-current" class="cui-input" />
        </div>
        <div class="cui-form-field" style="margin-top: 16px;">
          <label class="cui-label" for="password-new">New password</label>
          <input type="password" id="password-new" class="cui-input" />
        </div>
        <button class="cui-btn cui-btn--primary" style="margin-top: 24px;">Save password</button>
      </div>
    </div>
  </div>
</div>`

const css = `.cui-tabs {
  width: 100%;
  max-width: 500px;
}

.cui-tabs-radio {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}

.cui-tabs-list {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: hsl(var(--muted));
  border-radius: var(--radius);
  padding: 2px;
  margin-bottom: 0;
}

.cui-tabs-trigger {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 4px 12px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--muted-foreground));
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) - 2px);
  cursor: pointer;
  transition: all 0.15s ease;
  outline: none;
  position: relative;
  user-select: none;
}

.cui-tabs-trigger:hover {
  color: hsl(var(--foreground));
}

#cui-tab-account:checked ~ .cui-tabs-list .cui-tabs-trigger[for="cui-tab-account"],
#cui-tab-password:checked ~ .cui-tabs-list .cui-tabs-trigger[for="cui-tab-password"] {
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
}

.cui-tabs-trigger:focus-visible {
  outline: 2px solid hsl(var(--primary));
  outline-offset: 2px;
}

.cui-tabs-content-wrapper {
  position: relative;
  margin-top: 12px;
}

.cui-tabs-content {
  display: none;
  opacity: 0;
  transform: translateY(4px);
  transition: opacity 0.2s ease, transform 0.2s ease;
}

#cui-tab-account:checked ~ .cui-tabs-content-wrapper .cui-tabs-content[data-tab="account"],
#cui-tab-password:checked ~ .cui-tabs-content-wrapper .cui-tabs-content[data-tab="password"] {
  display: block;
  opacity: 1;
  transform: translateY(0);
}

.cui-tabs-content-inner {
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: 16px;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1);
  padding: 16px;
}

.cui-tabs-content-title {
  font-size: 1.125rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0 0 8px 0;
  line-height: 1.5;
}

.cui-tabs-content-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-form-field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cui-label {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-input {
  width: 100%;
  height: 40px;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
  outline: none;
}

.cui-input:focus {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-input::placeholder {
  color: hsl(var(--muted-foreground));
}

.cui-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 0.875rem;
  font-weight: 500;
  height: 32px;
  padding: 0 16px;
  border-radius: var(--radius);
  cursor: pointer;
  transition: opacity .15s ease, background-color .15s ease, color .15s ease;
}

.cui-btn--primary {
  background: hsl(var(--foreground));
  color: hsl(var(--background));
}

.cui-btn--primary:hover {
  opacity: 0.9;
}`

export default function TabsDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

