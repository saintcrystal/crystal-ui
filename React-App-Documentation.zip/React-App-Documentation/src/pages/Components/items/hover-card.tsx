import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'hover-card',
  name: 'Hover Card',
  description: 'For sighted users to preview content available behind a link',
}

const html = `<div class="cui-hover-card-wrapper">
  <a href="#" class="cui-hover-card-trigger">@username</a>
  <div class="cui-hover-card-bridge"></div>
  <div class="cui-hover-card-content">
    <div class="cui-hover-card-header">
      <div class="cui-hover-card-icon">
        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="40" height="40" rx="20" fill="hsl(var(--muted))"/>
          <circle cx="20" cy="15" r="4" fill="hsl(var(--muted-foreground))"/>
          <path d="M12 30C12 25 15 22 20 22C25 22 28 25 28 30" stroke="hsl(var(--muted-foreground))" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </div>
      <div class="cui-hover-card-info">
        <div class="cui-hover-card-title">@username</div>
        <div class="cui-hover-card-description">Software developer and open source enthusiast.</div>
      </div>
    </div>
    <div class="cui-hover-card-footer">
      <div class="cui-hover-card-meta">Joined January 2020</div>
    </div>
  </div>
</div>`

const css = `.cui-hover-card-wrapper {
  position: relative;
  display: inline-block;
}

.cui-hover-card-trigger {
  display: inline-block;
  color: hsl(var(--primary));
  text-decoration: underline;
  text-underline-offset: 4px;
  cursor: pointer;
  transition: opacity 0.15s ease;
}

.cui-hover-card-trigger:hover {
  opacity: 0.8;
}

.cui-hover-card-bridge {
  position: absolute;
  top: 100%;
  left: -20px;
  right: -20px;
  height: 12px;
  z-index: 49;
}

.cui-hover-card-content {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  z-index: 50;
  min-width: 280px;
  max-width: 320px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 16px;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease 0.05s, transform 0.15s ease 0.05s;
}

.cui-hover-card-wrapper:hover .cui-hover-card-content {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
  transition-delay: 0s;
}

.cui-hover-card-header {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 12px;
}

.cui-hover-card-icon {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
}

.cui-hover-card-info {
  flex: 1;
  min-width: 0;
}

.cui-hover-card-title {
  font-size: 0.875rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0 0 4px 0;
  line-height: 1.5;
}

.cui-hover-card-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-hover-card-footer {
  padding-top: 12px;
  border-top: 1px solid hsl(var(--border));
}

.cui-hover-card-meta {
  font-size: 0.75rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}`

export default function HoverCardDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

