import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'alert',
  name: 'Alert',
  description: 'Displays a callout for user attention',
}

const html = `<div class="cui-alert cui-alert--success" style="margin-bottom: 16px;">
  <svg class="cui-alert-icon" width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 12C10.2091 12 12 10.2091 12 8C12 5.79086 10.2091 4 8 4C5.79086 4 4 5.79086 4 8C4 10.2091 5.79086 12 8 12Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6 8L7.5 9.5L10 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
  <div class="cui-alert-content">
    <h4 class="cui-alert-title">Success! Your changes have been saved</h4>
    <p class="cui-alert-description">This is an alert with icon, title and description.</p>
  </div>
</div>

<div class="cui-alert" style="margin-bottom: 16px;">
  <svg class="cui-alert-icon" width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 2L2 5L8 8L14 5L8 2Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M2 5L8 8V14L2 11V5Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M14 5L8 8V14L14 11V5Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
  <div class="cui-alert-content">
    <h4 class="cui-alert-title">This Alert has a title and an icon. No description.</h4>
  </div>
</div>

<div class="cui-alert cui-alert--destructive" style="margin-bottom: 16px;">
  <svg class="cui-alert-icon" width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 12C10.2091 12 12 10.2091 12 8C12 5.79086 10.2091 4 8 4C5.79086 4 4 5.79086 4 8C4 10.2091 5.79086 12 8 12Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8 6V8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    <path d="M8 10H8.01" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  </svg>
  <div class="cui-alert-content">
    <h4 class="cui-alert-title">Unable to process your payment.</h4>
    <p class="cui-alert-description">Please verify your billing information and try again.</p>
    <ul class="cui-alert-list">
      <li>Check your card details</li>
      <li>Ensure sufficient funds</li>
      <li>Verify billing address</li>
    </ul>
  </div>
</div>`

const css = `.cui-alert {
  position: relative;
  width: 100%;
  border: 1px solid hsl(var(--border));
  border-radius: calc(var(--radius) + 4px);
  background: hsl(var(--background));
  padding: 16px;
  display: flex;
  gap: 12px;
}

.cui-alert-icon {
  flex-shrink: 0;
  width: 20px;
  height: 20px;
  margin-top: 2px;
  color: hsl(var(--foreground));
}

.cui-alert-content {
  flex: 1;
  min-width: 0;
}

.cui-alert-title {
  font-size: 0.875rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0 0 4px 0;
  line-height: 1.5;
}

.cui-alert-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-alert-list {
  margin: 8px 0 0 0;
  padding-left: 20px;
  color: hsl(var(--muted-foreground));
  font-size: 0.875rem;
  line-height: 1.75;
}

.cui-alert-list li {
  margin: 0;
}

.dark .cui-alert {
  background: hsl(0deg 0.01% 9.06%);
}

.dark .cui-alert--success {
  background: hsl(0deg 0.01% 9.06%);
}

.dark .cui-alert--destructive {
  background: hsl(0deg 0.01% 9.06%);
}

.cui-alert--destructive .cui-alert-icon {
  color: hsl(0 72% 51%);
}

.cui-alert--destructive .cui-alert-title,
.cui-alert--destructive .cui-alert-description,
.cui-alert--destructive .cui-alert-list {
  color: hsl(0 72% 51%);
}`

export default function AlertDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

