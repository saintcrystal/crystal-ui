import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'typography',
  name: 'Typography',
  description: 'Text styles for headings, paragraphs, lists, and more',
}

const html = `<div style="display: flex; flex-direction: column; gap: 32px;">
  <!-- Headings -->
  <div>
    <h1 class="cui-typography-h1">The Joke Tax Chronicles</h1>
    <h2 class="cui-typography-h2">People forget to tell you about the little pitfalls of maintaining relationships.</h2>
    <h3 class="cui-typography-h3">People forget to tell you about the little pitfalls of maintaining relationships.</h3>
    <h4 class="cui-typography-h4">People forget to tell you about the little pitfalls of maintaining relationships.</h4>
  </div>

  <!-- Paragraphs -->
  <div>
    <p class="cui-typography-p">The king, seeing how much happier his subjects were, realized the error of his ways and repealed the joke tax.</p>
    <p class="cui-typography-p">The king, seeing how much happier his subjects were, realized the error of his ways and repealed the joke tax.</p>
  </div>

  <!-- Blockquote -->
  <div>
    <blockquote class="cui-typography-blockquote">
      "After all," he said, "everyone enjoys a good joke, so it's only fair that they should pay for the privilege."
    </blockquote>
  </div>

  <!-- Lists -->
  <div>
    <ul class="cui-typography-ul">
      <li>1st level of puns: 5 gold coins</li>
      <li>2nd level of jokes: 10 gold coins</li>
      <li>3rd level of one-liners: 20 gold coins</li>
    </ul>
  </div>

  <div>
    <ol class="cui-typography-ol">
      <li>1st level of puns: 5 gold coins</li>
      <li>2nd level of jokes: 10 gold coins</li>
      <li>3rd level of one-liners: 20 gold coins</li>
    </ol>
  </div>

  <!-- Inline Elements -->
  <div>
    <p class="cui-typography-p">
      Inline <code class="cui-typography-code">code</code> element, <strong class="cui-typography-strong">strong</strong> text, and <em class="cui-typography-em">emphasized</em> text. Also <a href="#" class="cui-typography-link">a link</a>.
    </p>
  </div>

  <!-- Lead -->
  <div>
    <p class="cui-typography-lead">
      A modal dialog that interrupts the user with important content and expects a response.
    </p>
  </div>

  <!-- Large -->
  <div>
    <p class="cui-typography-large">Are you absolutely sure?</p>
  </div>

  <!-- Small -->
  <div>
    <p class="cui-typography-small">Email address</p>
  </div>

  <!-- Muted -->
  <div>
    <p class="cui-typography-muted">Enter your email address.</p>
  </div>
</div>`

const css = `.cui-typography-h1 {
  font-size: 2.25rem;
  font-weight: 800;
  letter-spacing: -0.025em;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.2;
}

.cui-typography-h2 {
  font-size: 1.875rem;
  font-weight: 700;
  letter-spacing: -0.025em;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.3;
}

.cui-typography-h3 {
  font-size: 1.5rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.4;
}

.cui-typography-h4 {
  font-size: 1.25rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-typography-p {
  font-size: 1rem;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.75;
}

.cui-typography-blockquote {
  font-size: 1rem;
  color: hsl(var(--foreground));
  border-left: 4px solid hsl(var(--border));
  padding-left: 1rem;
  margin: 0;
  line-height: 1.75;
  font-style: italic;
}

.cui-typography-ul {
  font-size: 1rem;
  color: hsl(var(--foreground));
  margin: 0;
  padding-left: 1.5rem;
  line-height: 1.75;
}

.cui-typography-ul li {
  margin: 0.25rem 0;
}

.cui-typography-ol {
  font-size: 1rem;
  color: hsl(var(--foreground));
  margin: 0;
  padding-left: 1.5rem;
  line-height: 1.75;
}

.cui-typography-ol li {
  margin: 0.25rem 0;
}

.cui-typography-code {
  font-size: 0.875rem;
  font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
  color: hsl(var(--foreground));
  background: hsl(var(--muted));
  padding: 0.125rem 0.375rem;
  border-radius: calc(var(--radius) - 2px);
}

.cui-typography-strong {
  font-weight: 600;
  color: hsl(var(--foreground));
}

.cui-typography-em {
  font-style: italic;
  color: hsl(var(--foreground));
}

.cui-typography-link {
  color: hsl(var(--primary));
  text-decoration: none;
  transition: opacity 0.15s ease;
}

.cui-typography-link:hover {
  opacity: 0.8;
  text-decoration: underline;
}

.cui-typography-lead {
  font-size: 1.25rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.625;
}

.cui-typography-large {
  font-size: 1.125rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-typography-small {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-typography-muted {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}`

export default function TypographyDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

