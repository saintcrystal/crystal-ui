import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'checkbox',
  name: 'Checkbox',
  description: 'A control that allows the user to toggle between checked and not checked',
}

const html = `<div class="cui-checkbox-group" style="margin-bottom: 16px;">
  <label class="cui-checkbox-label">
    <input type="checkbox" class="cui-checkbox-input" />
    <span class="cui-checkbox">
      <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </span>
    <span class="cui-checkbox-text">Accept terms and conditions</span>
  </label>
</div>

<div class="cui-checkbox-group" style="margin-bottom: 16px;">
  <label class="cui-checkbox-label">
    <input type="checkbox" class="cui-checkbox-input" checked />
    <span class="cui-checkbox">
      <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </span>
    <div class="cui-checkbox-text-wrapper">
      <span class="cui-checkbox-text">Accept terms and conditions</span>
      <span class="cui-checkbox-description">By clicking this checkbox, you agree to the terms and conditions.</span>
    </div>
  </label>
</div>

<div class="cui-checkbox-group" style="margin-bottom: 16px;">
  <label class="cui-checkbox-label">
    <input type="checkbox" class="cui-checkbox-input" />
    <span class="cui-checkbox">
      <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </span>
    <span class="cui-checkbox-text">Enable notifications</span>
  </label>
</div>

<div class="cui-checkbox-group" style="margin-bottom: 16px;">
  <label class="cui-checkbox-label cui-checkbox-label--highlight">
    <input type="checkbox" class="cui-checkbox-input" checked />
    <span class="cui-checkbox">
      <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </span>
    <div class="cui-checkbox-text-wrapper">
      <span class="cui-checkbox-text">Enable notifications</span>
      <span class="cui-checkbox-description">You can enable or disable notifications at any time.</span>
    </div>
  </label>
</div>`

const css = `.cui-checkbox-group {
  display: flex;
  align-items: flex-start;
}

.cui-checkbox-label {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  cursor: pointer;
  user-select: none;
}

.cui-checkbox-label--highlight {
  padding: 16px;
  border: 1px solid hsl(217.2 91.2% 59.8%);
  background: hsl(217.2 91.2% 95%);
  border-radius: var(--radius);
}

.dark .cui-checkbox-label--highlight {
  border: 1px solid hsl(217.2 70% 45%);
  background: hsl(217.2 50% 12%);
}

.cui-checkbox-input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.cui-checkbox {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  border: 1px solid hsl(var(--input));
  border-radius: calc(var(--radius) - 4px);
  background: hsl(var(--background));
  transition: all 0.15s ease;
  margin-top: 2px;
}

.cui-checkbox-input:checked ~ .cui-checkbox {
  background: hsl(var(--primary));
  border-color: hsl(var(--primary));
}

.cui-checkbox-input:focus-visible ~ .cui-checkbox {
  outline: 2px solid hsl(var(--primary));
  outline-offset: 2px;
}

.cui-checkbox-input:disabled ~ .cui-checkbox {
  opacity: 0.5;
  cursor: not-allowed;
}

.cui-checkbox-check {
  display: none;
  width: 12px;
  height: 12px;
  color: hsl(var(--primary-foreground));
}

.cui-checkbox-input:checked ~ .cui-checkbox .cui-checkbox-check {
  display: block;
}

.cui-checkbox-text-wrapper {
  display: flex;
  flex-direction: column;
  gap: 4px;
  flex: 1;
}

.cui-checkbox-text {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
  margin-left: 12px;
}

.cui-checkbox-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  line-height: 1.5;
  padding-left: 0;
  margin-left: 12px;
}`

export default function CheckboxDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

