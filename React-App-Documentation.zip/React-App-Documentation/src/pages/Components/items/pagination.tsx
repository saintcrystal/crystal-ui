import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'pagination',
  name: 'Pagination',
  description: 'Pagination with page navigation, next and previous links',
}

const html = `<nav class="cui-pagination" aria-label="pagination">
  <ul class="cui-pagination-list">
    <li class="cui-pagination-item">
      <a href="#" class="cui-pagination-link cui-pagination-link--prev" aria-label="Go to previous page">
        <svg class="cui-pagination-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 4L6 8L10 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Previous</span>
      </a>
    </li>
    <li class="cui-pagination-item">
      <a href="#" class="cui-pagination-link">1</a>
    </li>
    <li class="cui-pagination-item">
      <a href="#" class="cui-pagination-link cui-pagination-link--active">2</a>
    </li>
    <li class="cui-pagination-item">
      <a href="#" class="cui-pagination-link">3</a>
    </li>
    <li class="cui-pagination-item">
      <span class="cui-pagination-ellipsis">...</span>
    </li>
    <li class="cui-pagination-item">
      <a href="#" class="cui-pagination-link cui-pagination-link--next" aria-label="Go to next page">
        <span>Next</span>
        <svg class="cui-pagination-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </a>
    </li>
  </ul>
</nav>`

const css = `.cui-pagination {
  display: flex;
  align-items: center;
  justify-content: center;
}

.cui-pagination-list {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  list-style: none;
  padding: 0;
  margin: 0;
}

.cui-pagination-item {
  display: inline-flex;
  align-items: center;
}

.cui-pagination-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  min-width: 40px;
  height: 40px;
  padding: 0 16px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  background: transparent;
  border: 1px solid transparent;
  border-radius: calc(var(--radius) - 2px);
  text-decoration: none;
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease, border-color 0.15s ease;
}

.cui-pagination-link:hover {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-pagination-link--active {
  background: hsl(var(--primary));
  color: hsl(var(--primary-foreground));
  border-color: hsl(var(--primary));
}

.cui-pagination-link--active:hover {
  background: hsl(var(--primary));
  opacity: 0.9;
}

.cui-pagination-link--prev,
.cui-pagination-link--next {
  padding: 0 12px;
}

.cui-pagination-chevron {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: currentColor;
}

.cui-pagination-ellipsis {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 40px;
  height: 40px;
  padding: 0 8px;
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
}

.cui-pagination-link:disabled,
.cui-pagination-link[aria-disabled="true"] {
  opacity: 0.5;
  cursor: not-allowed;
  pointer-events: none;
}`

export default function PaginationDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

