import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'input-otp',
  name: 'Input OTP',
  description: 'Accessible one-time password input component',
}

const html = `<div class="cui-input-otp">
  <div class="cui-input-otp-group">
    <input type="text" class="cui-input-otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
    <input type="text" class="cui-input-otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
    <input type="text" class="cui-input-otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
    <div class="cui-input-otp-separator">-</div>
    <input type="text" class="cui-input-otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
    <input type="text" class="cui-input-otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
    <input type="text" class="cui-input-otp-input" maxlength="1" inputmode="numeric" pattern="[0-9]" />
  </div>
</div>`

const css = `.cui-input-otp {
  display: flex;
  justify-content: center;
}

.cui-input-otp-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.cui-input-otp-input {
  width: 48px;
  height: 48px;
  padding: 0;
  font-size: 1.5rem;
  font-weight: 600;
  text-align: center;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
  outline: none;
}

.cui-input-otp-input:focus {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-input-otp-separator {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 48px;
  font-size: 1.25rem;
  font-weight: 600;
  color: hsl(var(--muted-foreground));
}`

export default function InputOTPDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

