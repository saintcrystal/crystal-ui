import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'accordion',
  name: 'Accordion',
  description: 'Collapsible content sections without JavaScript',
}

const html = `<div class="cui-accordion">
  <details class="cui-accordion-item" open>
    <summary class="cui-accordion-trigger">
      Product Information
      <svg class="cui-accordion-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </summary>
    <div class="cui-accordion-content">
      <div class="cui-accordion-content-inner">
        Our flagship product combines cutting-edge technology with sleek design. Built with premium materials, it offers unparalleled performance and reliability. Key features include advanced processing capabilities, and an intuitive user interface designed for both beginners and experts.
      </div>
    </div>
  </details>
  <details class="cui-accordion-item">
    <summary class="cui-accordion-trigger">
      Shipping Details
      <svg class="cui-accordion-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </summary>
    <div class="cui-accordion-content">
      <div class="cui-accordion-content-inner">
        We offer free shipping on all orders over $50. Standard shipping takes 3-5 business days, while express shipping (available for an additional fee) delivers within 1-2 business days. All orders are carefully packaged and insured for safe delivery.
      </div>
    </div>
  </details>
  <details class="cui-accordion-item">
    <summary class="cui-accordion-trigger">
      Return Policy
      <svg class="cui-accordion-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </summary>
    <div class="cui-accordion-content">
      <div class="cui-accordion-content-inner">
        We offer a 30-day return policy on all unused items in their original packaging. Simply contact our customer service team to initiate a return. Refunds will be processed within 5-7 business days after we receive your returned item.
      </div>
    </div>
  </details>
</div>`

const css = `.cui-accordion {
  display: flex;
  flex-direction: column;
  background: hsl(var(--background));
  overflow: hidden;
}

.cui-accordion-item {
  border-bottom: 1px solid hsl(var(--border));
  overflow: hidden;
}

.cui-accordion-item:last-child {
  border-bottom: none;
}

.cui-accordion-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 16px;
  background: transparent;
  color: hsl(var(--foreground));
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  list-style: none;
  transition: background-color .2s ease;
  outline: none;
  -webkit-tap-highlight-color: transparent;
}

.cui-accordion-trigger::-webkit-details-marker {
  display: none;
}

.cui-accordion-trigger::marker {
  display: none;
}

.cui-accordion-trigger:hover {
  text-decoration: underline;
}

.cui-accordion-trigger:focus-visible {
  outline: 2px solid hsl(var(--primary));
  outline-offset: -2px;
}

.cui-accordion-chevron {
  flex-shrink: 0;
  margin-left: 16px;
  width: 16px;
  height: 16px;
  transition: transform .2s ease;
  color: hsl(var(--muted-foreground));
}

.cui-accordion-item[open] .cui-accordion-chevron {
  transform: rotate(180deg);
}

.cui-accordion-content {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 0.35s cubic-bezier(0.4, 0, 0.2, 1);
}

.cui-accordion-item[open] .cui-accordion-content {
  grid-template-rows: 1fr;
}

.cui-accordion-content-inner {
  min-height: 0;
  overflow: hidden;
  padding: 0 16px 16px;
  padding-top: 0;
  color: hsl(var(--muted-foreground));
  font-size: 0.875rem;
  line-height: 1.625;
}

.cui-accordion-item:not([open]) .cui-accordion-content-inner {
  opacity: 0;
  transition: opacity 0.2s ease;
}

.cui-accordion-item[open] .cui-accordion-content-inner {
  opacity: 1;
  transition: opacity 0.3s ease 0.1s;
}`

export default function AccordionDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

