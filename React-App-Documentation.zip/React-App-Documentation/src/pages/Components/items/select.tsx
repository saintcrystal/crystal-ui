import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'select',
  name: 'Select',
  description: 'Displays a list of options for the user to pick from—triggered by a button',
}

const html = `<div class="cui-select-wrapper">
  <input type="checkbox" id="cui-select-toggle" class="cui-select-checkbox" />
  <div class="cui-select">
    <label for="cui-select-toggle" class="cui-select-trigger">
      <span class="cui-select-value">Apple</span>
      <svg class="cui-select-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </label>
    <div class="cui-select-content">
      <div class="cui-select-group">
        <div class="cui-select-label">Fruits</div>
        <label for="cui-select-toggle" class="cui-select-item cui-select-item--selected">
          <span>Apple</span>
          <svg class="cui-select-check" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13 4L6 11L3 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </label>
        <label for="cui-select-toggle" class="cui-select-item">
          <span>Banana</span>
        </label>
        <label for="cui-select-toggle" class="cui-select-item">
          <span>Blueberry</span>
        </label>
        <label for="cui-select-toggle" class="cui-select-item">
          <span>Grapes</span>
        </label>
        <label for="cui-select-toggle" class="cui-select-item">
          <span>Pineapple</span>
        </label>
      </div>
    </div>
  </div>
  <label for="cui-select-toggle" class="cui-select-overlay"></label>
</div>`

const css = `.cui-select-wrapper {
  position: relative;
  display: inline-block;
  width: 100%;
  max-width: 200px;
}

.cui-select-checkbox {
  display: none;
}

.cui-select {
  position: relative;
  width: 100%;
}

.cui-select-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 40px;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  cursor: pointer;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
  outline: none;
}

.cui-select-trigger:hover {
  border-color: hsl(var(--input));
}

#cui-select-toggle:checked ~ .cui-select .cui-select-trigger {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-select-value {
  flex: 1;
  text-align: left;
  color: hsl(var(--foreground));
}

.cui-select-chevron {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
  transition: transform 0.15s ease;
}

#cui-select-toggle:checked ~ .cui-select .cui-select-chevron {
  transform: rotate(180deg);
}

.cui-select-content {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  z-index: 50;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
  overflow: hidden;
  padding: 4px;
}

#cui-select-toggle:checked ~ .cui-select .cui-select-content {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-select-group {
  display: flex;
  flex-direction: column;
}

.cui-select-label {
  padding: 8px 12px;
  font-size: 0.75rem;
  font-weight: 500;
  color: hsl(var(--muted-foreground));
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.cui-select-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  border-radius: calc(var(--radius) - 2px);
  cursor: pointer;
  transition: background-color 0.15s ease;
  outline: none;
}

.cui-select-item:hover {
  background: hsl(var(--muted));
}

.cui-select-item:focus-visible {
  background: hsl(var(--muted));
  outline: 2px solid hsl(var(--primary));
  outline-offset: -2px;
}

.cui-select-item--selected {
  background: hsl(var(--muted));
}

.cui-select-check {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--primary));
  margin-left: 8px;
}

.cui-select-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
  cursor: default;
}

#cui-select-toggle:checked ~ .cui-select-overlay {
  opacity: 1;
  pointer-events: auto;
}`

export default function SelectDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

