import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'button',
  name: 'Button',
  description: 'Action buttons with variants',
}

const html = `<button class="cui-btn cui-btn--primary">Button</button>
<button class="cui-btn cui-btn--outline" style="margin-left:8px">Outline</button>
<button class="cui-btn cui-btn--ghost" style="margin-left:8px">Ghost</button>
<button class="cui-btn cui-btn--link" style="margin-left:8px">Link</button>`

const css = `.cui-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 0.875rem;
  font-weight: 500;
  height: 32px;
  padding: 0 16px;
  border-radius: var(--radius);
  cursor: pointer;
  transition: opacity .15s ease, background-color .15s ease, color .15s ease;
}
.cui-btn:disabled { 
  opacity: .5; 
  cursor: not-allowed; 
}
.cui-btn--primary { 
  background: hsl(var(--primary)); 
  color: hsl(var(--primary-foreground)); 
}
.cui-btn--primary:hover {
  opacity: 0.9;
}
.cui-btn--outline { 
  background: transparent; 
  border: 1px solid hsl(var(--input)); 
}
.cui-btn--outline:hover {
  background: hsl(var(--muted));
}
.cui-btn--ghost { 
  background: transparent; 
}
.cui-btn--ghost:hover {
  background: hsl(var(--muted));
}
.cui-btn--link { 
  background: transparent; 
  color: hsl(var(--primary)); 
  text-decoration: underline; 
}
.cui-btn--link:hover {
  opacity: 0.8;
}`

export default function ButtonDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}
