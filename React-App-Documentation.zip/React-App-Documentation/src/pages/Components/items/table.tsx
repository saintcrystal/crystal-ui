import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'table',
  name: 'Table',
  description: 'A responsive table component',
}

const html = `<div class="cui-table-wrapper">
  <div class="cui-table-container">
    <table class="cui-table-base">
      <thead>
        <tr>
          <th class="cui-table-base-header">Invoice</th>
          <th class="cui-table-base-header">Status</th>
          <th class="cui-table-base-header">Method</th>
          <th class="cui-table-base-header cui-table-base-header--right">Amount</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="cui-table-base-cell">INV001</td>
          <td class="cui-table-base-cell">Paid</td>
          <td class="cui-table-base-cell">Credit Card</td>
          <td class="cui-table-base-cell cui-table-base-cell--right">$250.00</td>
        </tr>
        <tr>
          <td class="cui-table-base-cell">INV002</td>
          <td class="cui-table-base-cell">Pending</td>
          <td class="cui-table-base-cell">PayPal</td>
          <td class="cui-table-base-cell cui-table-base-cell--right">$150.00</td>
        </tr>
        <tr>
          <td class="cui-table-base-cell">INV003</td>
          <td class="cui-table-base-cell">Unpaid</td>
          <td class="cui-table-base-cell">Bank Transfer</td>
          <td class="cui-table-base-cell cui-table-base-cell--right">$350.00</td>
        </tr>
        <tr>
          <td class="cui-table-base-cell">INV004</td>
          <td class="cui-table-base-cell">Paid</td>
          <td class="cui-table-base-cell">Credit Card</td>
          <td class="cui-table-base-cell cui-table-base-cell--right">$450.00</td>
        </tr>
        <tr>
          <td class="cui-table-base-cell">INV005</td>
          <td class="cui-table-base-cell">Paid</td>
          <td class="cui-table-base-cell">Credit Card</td>
          <td class="cui-table-base-cell cui-table-base-cell--right">$550.00</td>
        </tr>
        <tr>
          <td class="cui-table-base-cell">INV006</td>
          <td class="cui-table-base-cell">Pending</td>
          <td class="cui-table-base-cell">PayPal</td>
          <td class="cui-table-base-cell cui-table-base-cell--right">$200.00</td>
        </tr>
        <tr>
          <td class="cui-table-base-cell">INV007</td>
          <td class="cui-table-base-cell">Unpaid</td>
          <td class="cui-table-base-cell">Bank Transfer</td>
          <td class="cui-table-base-cell cui-table-base-cell--right">$300.00</td>
        </tr>
        <tr class="cui-table-base-row--total">
          <td class="cui-table-base-cell cui-table-base-cell--total" colspan="3">Total</td>
          <td class="cui-table-base-cell cui-table-base-cell--right cui-table-base-cell--total">$2,500.00</td>
        </tr>
      </tbody>
    </table>
  </div>
  <p class="cui-table-caption">A list of your recent invoices.</p>
</div>`

const css = `.cui-table-wrapper {
  width: 100%;
}

.cui-table-container {
  width: 100%;
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  overflow: hidden;
  background: hsl(var(--background));
}

.cui-table-base {
  width: 100%;
  border-collapse: collapse;
}

.cui-table-base-header {
  padding: 12px 16px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--muted-foreground));
  text-align: left;
  border-bottom: 1px solid hsl(var(--border));
}

.cui-table-base-header--right {
  text-align: right;
}

.cui-table-base-row--total {
  border-top: 1px solid hsl(var(--border));
}

.cui-table-base-cell {
  padding: 12px 16px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  text-align: left;
  border-bottom: 1px solid hsl(var(--border));
}

.cui-table-base-cell--right {
  text-align: right;
}

.cui-table-base-cell--total {
  font-weight: 500;
  border-bottom: none;
}

tbody tr:last-child .cui-table-base-cell {
  border-bottom: none;
}

.cui-table-caption {
  margin-top: 16px;
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  text-align: center;
}`

export default function TableDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

