import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'input-group',
  name: 'Input Group',
  description: 'Display additional information or actions to an input or textarea',
}

const html = `<div style="display: flex; flex-direction: column; gap: 24px;">
  <!-- Search Input with icon and text -->
  <div class="cui-input-group">
    <div class="cui-input-group-wrapper">
      <div class="cui-input-group-left">
        <svg class="cui-input-group-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="7" cy="7" r="4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M11 11L14 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <input type="text" class="cui-input-group-input" placeholder="Search..." />
      </div>
      <div class="cui-input-group-right-text">12 results</div>
    </div>
  </div>

  <!-- URL Input with prefix and icon -->
  <div class="cui-input-group">
    <div class="cui-input-group-wrapper">
      <div class="cui-input-group-left">
        <span class="cui-input-group-prefix">https://</span>
        <input type="text" class="cui-input-group-input cui-input-group-input--no-left-padding" placeholder="example.com" />
      </div>
      <button class="cui-input-group-icon-button" type="button">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M8 6V8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M8 10H8.01" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
  </div>

  <!-- Textarea with controls -->
  <div class="cui-input-group">
    <div class="cui-input-group-wrapper cui-input-group-wrapper--textarea">
      <textarea class="cui-input-group-textarea" placeholder="Ask, Search or Chat..."></textarea>
      <div class="cui-input-group-footer">
        <button class="cui-input-group-footer-button" type="button">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 4V12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M4 8H12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </button>
        <span class="cui-input-group-footer-text">Auto</span>
        <span class="cui-input-group-footer-text" style="margin-left: auto;">52% used</span>
        <button class="cui-input-group-footer-button" type="button" style="margin-left: 8px;">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 10L8 6L12 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>
      </div>
    </div>
  </div>

  <!-- Username Input with prefix and checkmark -->
  <div class="cui-input-group">
    <div class="cui-input-group-wrapper">
      <div class="cui-input-group-left">
        <span class="cui-input-group-prefix">@</span>
        <input type="text" class="cui-input-group-input cui-input-group-input--no-left-padding" value="username" />
      </div>
      <button class="cui-input-group-icon-button cui-input-group-icon-button--success" type="button">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M13 4L6 11L3 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
    </div>
  </div>
</div>`

const css = `.cui-input-group {
  width: 100%;
  max-width: 400px;
}

.cui-input-group-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
}

.cui-input-group-wrapper:focus-within {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-input-group-wrapper--textarea {
  flex-direction: column;
  align-items: stretch;
  padding: 0;
}

.cui-input-group-left {
  display: flex;
  align-items: center;
  flex: 1;
  min-width: 0;
}

.cui-input-group-icon {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  margin-left: 12px;
  margin-right: 0px;
  color: hsl(var(--muted-foreground));
}

.cui-input-group-prefix {
  flex-shrink: 0;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
}

.cui-input-group-input {
  flex: 1;
  width: 100%;
  height: 35px;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  outline: none;
}

.cui-input-group-input--no-left-padding {
  padding-left: 0;
}

.cui-input-group-textarea {
  width: 100%;
  min-height: 100px;
  padding: 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  outline: none;
  resize: vertical;
  font-family: inherit;
}

.cui-input-group-right-text {
  flex-shrink: 0;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  white-space: nowrap;
}

.cui-input-group-icon-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 32px;
  height: 32px;
  margin: 4px;
  padding: 0;
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) - 2px);
  color: hsl(var(--muted-foreground));
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.cui-input-group-icon-button:hover {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-input-group-icon-button--success {
  color: hsl(142 71% 45%);
}

.cui-input-group-icon-button--success:hover {
  background: hsl(142 71% 45% / 0.1);
}

.cui-input-group-footer {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  border-top: 1px solid hsl(var(--border));
  gap: 8px;
}

.cui-input-group-footer-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  padding: 0;
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) - 2px);
  color: hsl(var(--muted-foreground));
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.cui-input-group-footer-button:hover {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-input-group-footer-text {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
}`

export default function InputGroupDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

