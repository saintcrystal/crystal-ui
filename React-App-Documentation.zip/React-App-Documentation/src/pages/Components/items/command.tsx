import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'command',
  name: 'Command',
  description: 'Fast, composable, unstyled command menu for React',
}

const html = `<div class="cui-command">
  <div class="cui-command-search">
    <svg class="cui-command-search-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="7" cy="7" r="4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
      <path d="M11 11L14 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    </svg>
    <input type="text" class="cui-command-search-input" placeholder="Type a command or search..." />
  </div>
  <div class="cui-command-separator"></div>
  <div class="cui-command-group">
    <div class="cui-command-group-heading">Suggestions</div>
    <div class="cui-command-list">
      <button class="cui-command-item cui-command-item--selected">
        <svg class="cui-command-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="2" y="4" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M6 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M10 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M2 8H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <span>Calendar</span>
      </button>
      <button class="cui-command-item">
        <svg class="cui-command-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M6 8C6 9 7 10 8 10C9 10 10 9 10 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M8 6V8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <span>Search Emoji</span>
      </button>
      <button class="cui-command-item">
        <svg class="cui-command-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="2" y="2" width="12" height="12" rx="1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M5 6H11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M5 10H11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <span>Calculator</span>
      </button>
    </div>
  </div>
  <div class="cui-command-separator"></div>
  <div class="cui-command-group">
    <div class="cui-command-group-heading">Settings</div>
    <div class="cui-command-list">
      <button class="cui-command-item">
        <svg class="cui-command-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="8" cy="5" r="2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M4 13C4 10.5 5.5 9 8 9C10.5 9 12 10.5 12 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <span>Profile</span>
        <span class="cui-command-shortcut">⌘P</span>
      </button>
      <button class="cui-command-item">
        <svg class="cui-command-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="2" y="4" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M2 7H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M6 4V2H10V4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <span>Billing</span>
        <span class="cui-command-shortcut">⌘B</span>
      </button>
      <button class="cui-command-item">
        <svg class="cui-command-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="8" cy="8" r="2.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M8 2V4M8 12V14M4 8H2M14 8H12M4.343 4.343L5.757 5.757M10.243 10.243L11.657 11.657M4.343 11.657L5.757 10.243M10.243 5.757L11.657 4.343" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
        <span>Settings</span>
        <span class="cui-command-shortcut">⌘S</span>
      </button>
    </div>
  </div>
</div>`

const css = `.cui-command {
  width: 100%;
  max-width: 480px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.cui-command-search {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px;
  border-bottom: 1px solid hsl(var(--border));
}

.cui-command-search-icon {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
}

.cui-command-search-input {
  flex: 1;
  height: 24px;
  padding: 0 8px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  outline: none;
}

.cui-command-search-input::placeholder {
  color: hsl(var(--muted-foreground));
}

.cui-command-separator {
  height: 1px;
  background: hsl(var(--border));
  margin: 0;
}

.cui-command-group {
  padding: 4px 0;
}

.cui-command-group-heading {
  padding: 6px 12px;
  font-size: 0.75rem;
  font-weight: 500;
  color: hsl(var(--muted-foreground));
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.cui-command-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.cui-command-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 12px;
  margin: 0px 8px;
  border-radius: 8px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  cursor: pointer;
  text-align: left;
  transition: background-color 0.15s ease;
}

.cui-command-item:hover {
  background: hsl(var(--muted));
}

.cui-command-item--selected {
  background: hsl(var(--muted));
}

.cui-command-icon {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
}

.cui-command-item span:not(.cui-command-shortcut) {
  flex: 1;
}

.cui-command-shortcut {
  flex-shrink: 0;
  padding: 2px 6px;
  font-size: 0.75rem;
  font-weight: 500;
  color: hsl(var(--muted-foreground));
  background: hsl(var(--muted));
  border-radius: calc(var(--radius) - 2px);
  font-family: ui-monospace, monospace;
}`

export default function CommandDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

