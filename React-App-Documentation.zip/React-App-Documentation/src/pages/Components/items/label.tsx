import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'label',
  name: 'Label',
  description: 'Renders an accessible label associated with controls',
}

const html = `<div class="cui-checkbox-group">
  <label class="cui-checkbox-label">
    <input type="checkbox" class="cui-checkbox-input" />
    <span class="cui-checkbox">
      <svg class="cui-checkbox-check" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </span>
    <span class="cui-label-text">Accept terms and conditions</span>
  </label>
</div>`

const css = `.cui-label-text {
  font-size: 1rem;
  font-weight: normal;
  color: hsl(var(--foreground));
  line-height: 1.5;
  margin-left: 12px;
}`

export default function LabelDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

