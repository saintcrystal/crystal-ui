import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'button-group',
  name: 'Button Group',
  description: 'A container that groups related buttons together with consistent styling',
}

const html = `<div class="cui-button-group-wrapper">
  <input type="checkbox" id="cui-button-group-dropdown" class="cui-button-group-checkbox" />
  <div class="cui-button-group">
    <button class="cui-btn cui-btn--outline cui-btn-group-item cui-btn-group-item--first">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 4L6 8L10 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </button>
    <button class="cui-btn cui-btn--outline cui-btn-group-item">Archive</button>
    <button class="cui-btn cui-btn--outline cui-btn-group-item">Report</button>
    <label for="cui-button-group-dropdown" class="cui-btn cui-btn--outline cui-btn-group-item cui-btn-group-item--last cui-btn-group-dropdown-trigger">
      Snooze
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left: 8px;">
        <circle cx="4" cy="8" r="1.5" fill="currentColor"/>
        <circle cx="8" cy="8" r="1.5" fill="currentColor"/>
        <circle cx="12" cy="8" r="1.5" fill="currentColor"/>
      </svg>
    </label>
    <div class="cui-button-group-dropdown">
      <div class="cui-button-group-dropdown-content">
        <a href="#" class="cui-button-group-dropdown-item">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 4L8 2L14 4V12L8 14L2 12V4Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 6V10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <span>Mark as Read</span>
        </a>
        <a href="#" class="cui-button-group-dropdown-item">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 4H14V12H2V4Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M6 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M10 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <span>Archive</span>
        </a>
        <a href="#" class="cui-button-group-dropdown-item">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 4V8L10 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>Snooze</span>
        </a>
        <a href="#" class="cui-button-group-dropdown-item">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="4" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M6 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M10 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M4 8H12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <span>Add to Calendar</span>
        </a>
        <a href="#" class="cui-button-group-dropdown-item">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 4H13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M3 8H13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M3 12H13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <span>Add to List</span>
        </a>
        <a href="#" class="cui-button-group-dropdown-item">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 6L8 2L14 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 2V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M3 10L8 14L13 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>Label As...</span>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left: auto;">
            <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </a>
        <div class="cui-button-group-dropdown-separator"></div>
        <a href="#" class="cui-button-group-dropdown-item cui-button-group-dropdown-item--destructive">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 4L12 12M12 4L4 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <span>Trash</span>
        </a>
      </div>
    </div>
  </div>
  <label for="cui-button-group-dropdown" class="cui-button-group-overlay"></label>
</div>`

const css = `.cui-button-group-wrapper {
  position: relative;
  display: inline-block;
}

.cui-button-group-checkbox {
  display: none;
}

.cui-button-group {
  display: inline-flex;
  align-items: center;
  border-radius: var(--radius);
  overflow: visible;
  border: 1px solid hsl(var(--input));
  position: relative;
}

.cui-btn-group-item {
  border-radius: 0;
  border: none;
  border-right: 1px solid hsl(var(--input));
  margin: 0;
  padding: 0 16px;
}

.cui-btn-group-item--first {
  border-top-left-radius: calc(var(--radius) - 1px);
  border-bottom-left-radius: calc(var(--radius) - 1px);
}

.cui-btn-group-item--last {
  border-top-right-radius: calc(var(--radius) - 1px);
  border-bottom-right-radius: calc(var(--radius) - 1px);
  border-right: none;
}

.cui-btn-group-item:hover {
  background: hsl(var(--muted));
}

.cui-btn-group-dropdown-trigger {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
}

.cui-button-group-dropdown {
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  z-index: 50;
  min-width: 200px;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
}

.cui-button-group-checkbox:checked ~ .cui-button-group .cui-button-group-dropdown {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-button-group-dropdown-content {
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 4px;
  display: flex;
  flex-direction: column;
}

.cui-button-group-dropdown-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  text-decoration: none;
  border-radius: calc(var(--radius) - 2px);
  transition: background-color 0.15s ease;
  cursor: pointer;
}

.cui-button-group-dropdown-item:hover {
  background: hsl(var(--muted));
}

.cui-button-group-dropdown-item svg {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
}

.cui-button-group-dropdown-item span {
  flex: 1;
}

.cui-button-group-dropdown-item--destructive {
  color: hsl(0 72% 51%);
}

.cui-button-group-dropdown-item--destructive svg {
  color: hsl(0 72% 51%);
}

.cui-button-group-dropdown-item--destructive:hover {
  background: hsl(0 72% 51% / 0.1);
}

.cui-button-group-dropdown-separator {
  height: 1px;
  background: hsl(var(--border));
  margin: 4px 0;
}

.cui-button-group-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
}

.cui-button-group-checkbox:checked ~ .cui-button-group-overlay {
  opacity: 1;
  pointer-events: auto;
}`

export default function ButtonGroupDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

