import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'sonner',
  name: 'Sonner',
  description: 'An opinionated toast component for React',
}

const html = `<div class="cui-sonner-wrapper">
  <input type="checkbox" id="cui-sonner-toggle" class="cui-sonner-checkbox" />
  <label for="cui-sonner-toggle" class="cui-btn cui-btn--primary">Show Toast</label>
  <div class="cui-sonner-container">
    <div class="cui-sonner-toast">
      <div class="cui-sonner-content">
        <div class="cui-sonner-main">
          <div class="cui-sonner-title">Event has been created</div>
          <div class="cui-sonner-description">Sunday, December 03, 2023 at 9:00 AM</div>
        </div>
        <label for="cui-sonner-toggle" class="cui-sonner-action">
          Undo
        </label>
      </div>
    </div>
  </div>
</div>`

const css = `.cui-sonner-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 400px;
}

.cui-sonner-checkbox {
  display: none;
}

.cui-sonner-container {
  position: fixed;
  top: 16px;
  right: 16px;
  z-index: 100;
  pointer-events: none;
}

.cui-sonner-toast {
  display: flex;
  align-items: center;
  width: 100%;
  max-width: 356px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 16px;
  opacity: 0;
  transform: translateX(calc(100% + 16px));
  transition: opacity 0.3s ease, transform 0.3s ease;
  pointer-events: none;
}

#cui-sonner-toggle:checked ~ .cui-sonner-container .cui-sonner-toast {
  opacity: 1;
  transform: translateX(0);
  pointer-events: auto;
}

.cui-sonner-content {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
}

.cui-sonner-main {
  flex: 1;
  min-width: 0;
}

.cui-sonner-title {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
  margin: 0 0 4px 0;
}

.cui-sonner-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  line-height: 1.5;
  margin: 0;
}

.cui-sonner-action {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 32px;
  padding: 0 12px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--background));
  background: hsl(var(--foreground));
  border: none;
  border-radius: calc(var(--radius) - 2px);
  cursor: pointer;
  transition: opacity 0.15s ease, background-color 0.15s ease;
  flex-shrink: 0;
}

.cui-sonner-action:hover {
  opacity: 0.9;
  background: hsl(var(--foreground));
}`

export default function SonnerDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

