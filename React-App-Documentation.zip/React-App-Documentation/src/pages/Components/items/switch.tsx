import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'switch',
  name: 'Switch',
  description: 'A control that allows the user to toggle between checked and not checked',
}

const html = `<div class="cui-switch-group" style="margin-bottom: 16px;">
  <label class="cui-switch-label">
    <input type="checkbox" class="cui-switch-input" />
    <span class="cui-switch">
      <span class="cui-switch-thumb"></span>
    </span>
    <span class="cui-switch-text">Airplane Mode</span>
  </label>
</div>

<div class="cui-switch-group" style="margin-bottom: 16px;">
  <label class="cui-switch-label">
    <input type="checkbox" class="cui-switch-input" checked />
    <span class="cui-switch">
      <span class="cui-switch-thumb"></span>
    </span>
    <span class="cui-switch-text">Airplane Mode</span>
  </label>
</div>

<div class="cui-switch-group" style="margin-bottom: 16px;">
  <label class="cui-switch-label">
    <input type="checkbox" class="cui-switch-input" />
    <span class="cui-switch">
      <span class="cui-switch-thumb"></span>
    </span>
    <div class="cui-switch-text-wrapper">
      <span class="cui-switch-text">Enable notifications</span>
      <span class="cui-switch-description">Receive notifications about your account activity.</span>
    </div>
  </label>
</div>

<div class="cui-switch-group">
  <label class="cui-switch-label">
    <input type="checkbox" class="cui-switch-input" disabled />
    <span class="cui-switch">
      <span class="cui-switch-thumb"></span>
    </span>
    <span class="cui-switch-text">Disabled</span>
  </label>
</div>`

const css = `.cui-switch-group {
  display: flex;
  align-items: flex-start;
}

.cui-switch-label {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  cursor: pointer;
  user-select: none;
}

.cui-switch-input {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.cui-switch {
  position: relative;
  display: inline-flex;
  align-items: center;
  width: 44px;
  height: 24px;
  flex-shrink: 0;
  border-radius: 9999px;
  background: hsl(var(--input));
  border: none;
  cursor: pointer;
  transition: background-color 0.2s ease;
  margin-top: 2px;
}

.cui-switch-input:checked ~ .cui-switch {
  background: hsl(var(--primary));
}

.cui-switch-input:focus-visible ~ .cui-switch {
  outline: 2px solid hsl(var(--primary));
  outline-offset: 2px;
}

.cui-switch-input:disabled ~ .cui-switch {
  opacity: 0.5;
  cursor: not-allowed;
}

.cui-switch-thumb {
  display: block;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: hsl(var(--background));
  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2);
  transition: transform 0.2s ease;
  transform: translateX(2px);
}

.cui-switch-input:checked ~ .cui-switch .cui-switch-thumb {
  transform: translateX(22px);
}

.cui-switch-text-wrapper {
  display: flex;
  flex-direction: column;
  gap: 4px;
  flex: 1;
}

.cui-switch-text {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-switch-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  line-height: 1.5;
}`

export default function SwitchDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

