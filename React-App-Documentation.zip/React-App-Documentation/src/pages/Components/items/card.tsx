import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'card',
  name: 'Card',
  description: 'Displays a card with header, content, and footer',
}

const html = `<div class="cui-card">
  <div class="cui-card-header">
    <div class="cui-card-header-content">
      <h3 class="cui-card-title">Login to your account</h3>
      <a href="#" class="cui-card-link">Sign Up</a>
    </div>
    <p class="cui-card-description">Enter your email below to login to your account</p>
  </div>
  <div class="cui-card-content">
    <div class="cui-form-field">
      <label class="cui-label" for="email">Email</label>
      <input type="email" id="email" class="cui-input" placeholder="m@example.com" />
    </div>
    <div class="cui-form-field">
      <div class="cui-label-row">
        <label class="cui-label" for="password">Password</label>
        <a href="#" class="cui-link">Forgot your password?</a>
      </div>
      <input type="password" id="password" class="cui-input" />
    </div>
  </div>
  <div class="cui-card-footer">
    <button class="cui-btn cui-btn--primary" style="width: 100%;">Login</button>
    <button class="cui-btn cui-btn--outline" style="width: 100%; margin-top: 8px;">Login with Google</button>
  </div>
</div>`

const css = `.cui-card {
  width: 100%;
  max-width: 384px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1);
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 0;
}

.cui-card-header {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 24px;
}

.cui-card-header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.cui-card-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-card-link {
  font-size: 0.875rem;
  color: hsl(var(--primary));
  text-decoration: none;
  transition: opacity 0.15s ease;
}

.cui-card-link:hover {
  opacity: 0.8;
  text-decoration: underline;
}

.cui-card-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-card-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-bottom: 24px;
}

.cui-card-footer {
  display: flex;
  flex-direction: column;
  gap: 0;
}

.cui-form-field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cui-label-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.cui-label {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-input {
  width: 100%;
  height: 40px;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
  outline: none;
}

.cui-input:focus {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-input::placeholder {
  color: hsl(var(--muted-foreground));
}

.cui-link {
  font-size: 0.875rem;
  color: hsl(var(--primary));
  text-decoration: none;
  transition: opacity 0.15s ease;
}

.cui-link:hover {
  opacity: 0.8;
  text-decoration: underline;
}`

export default function CardDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

