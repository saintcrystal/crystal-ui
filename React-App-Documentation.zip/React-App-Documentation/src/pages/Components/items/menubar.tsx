import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'menubar',
  name: 'Menubar',
  description: 'A visually persistent menu common in desktop applications',
}

const html = `<div class="cui-menubar-wrapper">
  <input type="checkbox" id="cui-menubar-file" class="cui-menubar-checkbox" />
  <div class="cui-menubar">
    <label for="cui-menubar-file" class="cui-menubar-trigger">File</label>
    <div class="cui-menubar-item">Edit</div>
    <div class="cui-menubar-item">View</div>
    <div class="cui-menubar-item">Profiles</div>
    <div class="cui-menubar-menu">
      <div class="cui-menubar-menu-content">
        <a href="#" class="cui-menubar-menu-item">
          <span>New Tab</span>
          <span class="cui-menubar-menu-shortcut">⌘T</span>
        </a>
        <a href="#" class="cui-menubar-menu-item">
          <span>New Window</span>
          <span class="cui-menubar-menu-shortcut">⌘N</span>
        </a>
        <a href="#" class="cui-menubar-menu-item">
          <span>New Incognito Window</span>
        </a>
        <a href="#" class="cui-menubar-menu-item">
          <span>Share</span>
          <svg class="cui-menubar-menu-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </a>
        <a href="#" class="cui-menubar-menu-item">
          <span>Print...</span>
          <span class="cui-menubar-menu-shortcut">⌘P</span>
        </a>
      </div>
    </div>
  </div>
  <label for="cui-menubar-file" class="cui-menubar-overlay"></label>
</div>`

const css = `.cui-menubar-wrapper {
  position: relative;
  display: inline-block;
}

.cui-menubar-checkbox {
  display: none;
}

.cui-menubar {
  display: inline-flex;
  align-items: center;
  gap: 0;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  padding: 2px;
}

.cui-menubar-trigger,
.cui-menubar-item {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 4px 12px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) - 2px);
  cursor: pointer;
  transition: background-color 0.15s ease;
  outline: none;
}

.cui-menubar-trigger:hover,
.cui-menubar-item:hover {
  background: hsl(var(--muted));
}

#cui-menubar-file:checked ~ .cui-menubar .cui-menubar-trigger {
  background: hsl(var(--muted));
}

.cui-menubar-menu {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  z-index: 50;
  min-width: 240px;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
}

#cui-menubar-file:checked ~ .cui-menubar .cui-menubar-menu {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-menubar-menu-content {
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 4px;
  display: flex;
  flex-direction: column;
}

.cui-menubar-menu-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 4px 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  text-decoration: none;
  border-radius: calc(var(--radius) - 2px);
  transition: background-color 0.15s ease;
  cursor: pointer;
}

.cui-menubar-menu-item:hover {
  background: hsl(var(--muted));
}

.cui-menubar-menu-shortcut {
  font-size: 0.75rem;
  color: hsl(var(--muted-foreground));
  margin-left: 32px;
  letter-spacing: 0.05em;
}

.cui-menubar-menu-chevron {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  margin-left: 32px;
  color: hsl(var(--muted-foreground));
}

.cui-menubar-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
  cursor: default;
}

#cui-menubar-file:checked ~ .cui-menubar-overlay {
  opacity: 1;
  pointer-events: auto;
}`

export default function MenubarDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

