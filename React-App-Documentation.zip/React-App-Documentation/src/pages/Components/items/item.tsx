import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'item',
  name: 'Item',
  description: 'A versatile component that you can use to display any content',
}

const html = `<div style="display: flex; flex-direction: column; gap: 16px; max-width: 600px;">
  <!-- Basic Item -->
  <div class="cui-item">
    <div class="cui-item-content">
      <div class="cui-item-title">Basic Item</div>
      <div class="cui-item-description">A simple item with title and description.</div>
    </div>
    <div class="cui-item-action">
      <button class="cui-btn cui-btn--outline">Action</button>
    </div>
  </div>

  <!-- Item with Icon -->
  <div class="cui-item">
    <div class="cui-item-icon">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="8" cy="8" r="6" fill="hsl(var(--foreground))"/>
        <path d="M5 8L7 10L11 6" stroke="hsl(var(--background))" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </div>
    <div class="cui-item-content">
      <div class="cui-item-title">Your profile has been verified.</div>
    </div>
    <div class="cui-item-action">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </div>
  </div>
</div>`

const css = `.cui-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  transition: background-color 0.15s ease;
}

.cui-item-content {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cui-item-title {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
  margin: 0;
}

.cui-item-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  line-height: 1.5;
  margin: 0;
}

.cui-item-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: hsl(var(--foreground));
}

.cui-item-action {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  color: hsl(var(--muted-foreground));
}

.cui-item-action svg {
  width: 16px;
  height: 16px;
}`

export default function ItemDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

