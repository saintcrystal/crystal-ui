import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'empty',
  name: 'Empty',
  description: 'A component to display empty states',
}

const html = `<div class="cui-empty">
  <div class="cui-empty-icon">
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="8" y="12" width="48" height="40" rx="2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M8 20L32 36L56 20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M18 12V8C18 6.89543 18.8954 6 20 6H44C45.1046 6 46 6.89543 46 8V12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </div>
  <h3 class="cui-empty-title">No items found</h3>
  <p class="cui-empty-description">Start by creating a new item.</p>
  <button class="cui-btn cui-btn--primary" style="margin-top: 16px;">Create Item</button>
</div>`

const css = `.cui-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 48px 24px;
  text-align: center;
}

.cui-empty-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 64px;
  height: 64px;
  margin-bottom: 16px;
  color: hsl(var(--muted-foreground));
  opacity: 0.5;
}

.cui-empty-title {
  font-size: 1.125rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  margin: 0 0 8px 0;
  line-height: 1.5;
}

.cui-empty-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}`

export default function EmptyDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

