import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'date-picker',
  name: 'Date Picker',
  description: 'A date picker component with range',
}

const html = `<div class="cui-date-picker-wrapper">
  <input type="checkbox" id="cui-date-picker-toggle" class="cui-date-picker-checkbox" />
  <div class="cui-date-picker">
    <label for="cui-date-picker-toggle" class="cui-date-picker-input-wrapper">
      <input type="text" class="cui-date-picker-input" value="27/11/2025" readonly />
      <svg class="cui-date-picker-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </label>
    <div class="cui-date-picker-popup">
      <div class="cui-calendar">
        <div class="cui-calendar-header">
          <div class="cui-calendar-nav">
            <button class="cui-calendar-nav-button" aria-label="Previous month">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M10 4L6 8L10 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
            <div class="cui-calendar-month-year">
              <div class="cui-calendar-month">
                Nov
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
              <div class="cui-calendar-year">
                2025
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
            </div>
            <button class="cui-calendar-nav-button" aria-label="Next month">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6 4L10 8L6 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
        <div class="cui-calendar-body">
          <div class="cui-calendar-weekdays">
            <div class="cui-calendar-weekday">Su</div>
            <div class="cui-calendar-weekday">Mo</div>
            <div class="cui-calendar-weekday">Tu</div>
            <div class="cui-calendar-weekday">We</div>
            <div class="cui-calendar-weekday">Th</div>
            <div class="cui-calendar-weekday">Fr</div>
            <div class="cui-calendar-weekday">Sa</div>
          </div>
          <div class="cui-calendar-days">
            <button class="cui-calendar-day cui-calendar-day--outside">26</button>
            <button class="cui-calendar-day cui-calendar-day--outside">27</button>
            <button class="cui-calendar-day cui-calendar-day--outside">28</button>
            <button class="cui-calendar-day cui-calendar-day--outside">29</button>
            <button class="cui-calendar-day cui-calendar-day--outside">30</button>
            <button class="cui-calendar-day cui-calendar-day--outside">31</button>
            <button class="cui-calendar-day">1</button>
            <button class="cui-calendar-day">2</button>
            <button class="cui-calendar-day">3</button>
            <button class="cui-calendar-day">4</button>
            <button class="cui-calendar-day">5</button>
            <button class="cui-calendar-day">6</button>
            <button class="cui-calendar-day">7</button>
            <button class="cui-calendar-day">8</button>
            <button class="cui-calendar-day">9</button>
            <button class="cui-calendar-day">10</button>
            <button class="cui-calendar-day">11</button>
            <button class="cui-calendar-day">12</button>
            <button class="cui-calendar-day">13</button>
            <button class="cui-calendar-day">14</button>
            <button class="cui-calendar-day">15</button>
            <button class="cui-calendar-day">16</button>
            <button class="cui-calendar-day">17</button>
            <button class="cui-calendar-day">18</button>
            <button class="cui-calendar-day">19</button>
            <button class="cui-calendar-day">20</button>
            <button class="cui-calendar-day">21</button>
            <button class="cui-calendar-day">22</button>
            <button class="cui-calendar-day">23</button>
            <button class="cui-calendar-day">24</button>
            <button class="cui-calendar-day">25</button>
            <button class="cui-calendar-day">26</button>
            <button class="cui-calendar-day cui-calendar-day--selected">27</button>
            <button class="cui-calendar-day">28</button>
            <button class="cui-calendar-day">29</button>
            <button class="cui-calendar-day">30</button>
            <button class="cui-calendar-day cui-calendar-day--outside">1</button>
            <button class="cui-calendar-day cui-calendar-day--outside">2</button>
            <button class="cui-calendar-day cui-calendar-day--outside">3</button>
            <button class="cui-calendar-day cui-calendar-day--outside">4</button>
            <button class="cui-calendar-day cui-calendar-day--outside">5</button>
            <button class="cui-calendar-day cui-calendar-day--outside">6</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <label for="cui-date-picker-toggle" class="cui-date-picker-overlay"></label>
</div>`

const css = `.cui-date-picker-wrapper {
  position: relative;
  display: inline-block;
}

.cui-date-picker-checkbox {
  display: none;
}

.cui-date-picker {
  position: relative;
}

.cui-date-picker-input-wrapper {
  display: flex;
  align-items: center;
  cursor: pointer;
  position: relative;
}

.cui-date-picker-input {
  width: 100%;
  height: 40px;
  padding: 0 36px 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
  outline: none;
  cursor: pointer;
  pointer-events: none;
}

#cui-date-picker-toggle:checked ~ .cui-date-picker .cui-date-picker-input-wrapper .cui-date-picker-input {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-date-picker-icon {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
  pointer-events: none;
}

.cui-date-picker-popup {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  z-index: 9999;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
}

#cui-date-picker-toggle:checked ~ .cui-date-picker .cui-date-picker-popup {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-date-picker-popup .cui-calendar {
  width: 100%;
  max-width: 224px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  padding: 12px;
}

.cui-date-picker-overlay {
  position: fixed;
  inset: 0;
  z-index: 9998;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
  cursor: default;
}

#cui-date-picker-toggle:checked ~ .cui-date-picker-overlay {
  opacity: 1;
  pointer-events: auto;
}`

export default function DatePickerDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

