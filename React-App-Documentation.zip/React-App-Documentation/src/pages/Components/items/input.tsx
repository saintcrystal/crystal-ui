import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'input',
  name: 'Input',
  description: 'Displays a form input field or a component that looks like an input field',
}

const html = `<div style="display: flex; flex-direction: column; gap: 24px; max-width: 400px;">
  <!-- Basic Input -->
  <div class="cui-input-field">
    <input type="text" class="cui-input" placeholder="Email" />
  </div>

  <!-- Input with Label -->
  <div class="cui-input-field">
    <label class="cui-label" for="email-input">Email</label>
    <input type="email" id="email-input" class="cui-input" placeholder="name@example.com" />
  </div>

  <!-- Input with Label and Description -->
  <div class="cui-input-field">
    <label class="cui-label" for="password-input">Password</label>
    <input type="password" id="password-input" class="cui-input" placeholder="Enter your password" />
    <p class="cui-input-description">Your password must be at least 8 characters.</p>
  </div>

  <!-- Input with Error -->
  <div class="cui-input-field">
    <label class="cui-label" for="error-input">Email</label>
    <input type="email" id="error-input" class="cui-input cui-input--error" placeholder="name@example.com" value="invalid-email" />
    <p class="cui-input-error">Please enter a valid email address.</p>
  </div>

  <!-- Disabled Input -->
  <div class="cui-input-field">
    <label class="cui-label" for="disabled-input">Disabled</label>
    <input type="text" id="disabled-input" class="cui-input" placeholder="Disabled input" disabled />
  </div>

  <!-- Input with Value -->
  <div class="cui-input-field">
    <label class="cui-label" for="filled-input">Name</label>
    <input type="text" id="filled-input" class="cui-input" value="Pedro Duarte" />
  </div>
</div>`

const css = `.cui-input-field {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cui-input {
  width: 100%;
  height: 40px;
  padding: 0 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  background: hsl(var(--background));
  border: 1px solid hsl(var(--input));
  border-radius: var(--radius);
  transition: border-color 0.15s ease;
  outline: none;
}

.cui-input:focus {
  border-color: hsl(var(--primary));
  box-shadow: 0 0 0 2px hsl(var(--primary) / 0.1);
}

.cui-input::placeholder {
  color: hsl(var(--muted-foreground));
}

.cui-input:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.cui-input--error {
  border-color: hsl(0 72% 51%);
}

.cui-input--error:focus {
  border-color: hsl(0 72% 51%);
  box-shadow: 0 0 0 2px hsl(0 72% 51% / 0.1);
}

.cui-label {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-input-description {
  font-size: 0.875rem;
  color: hsl(var(--muted-foreground));
  margin: 0;
  line-height: 1.5;
}

.cui-input-error {
  font-size: 0.875rem;
  color: hsl(0 72% 51%);
  margin: 0;
  line-height: 1.5;
}`

export default function InputDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

