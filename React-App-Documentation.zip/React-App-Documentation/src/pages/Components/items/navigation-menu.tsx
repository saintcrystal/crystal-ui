import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'navigation-menu',
  name: 'Navigation Menu',
  description: 'A collection of links for navigating websites',
}

const html = `<nav class="cui-navigation-menu">
  <input type="checkbox" id="cui-nav-home" class="cui-nav-checkbox" />
  <input type="checkbox" id="cui-nav-components" class="cui-nav-checkbox" />
  <input type="checkbox" id="cui-nav-list" class="cui-nav-checkbox" />
  <input type="checkbox" id="cui-nav-simple" class="cui-nav-checkbox" />
  <input type="checkbox" id="cui-nav-with-icon" class="cui-nav-checkbox" />
  
  <div class="cui-nav-list">
    <div class="cui-nav-item-wrapper cui-nav-item-wrapper--home">
      <label for="cui-nav-home" class="cui-nav-trigger">
        Home
        <svg class="cui-nav-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </label>
      <div class="cui-nav-content cui-nav-content--home">
        <div class="cui-nav-grid">
          <div class="cui-nav-featured">
            <div class="cui-nav-featured-title">Crystal UI</div>
            <div class="cui-nav-featured-description">A lightweight CSS library with beautifully designed components.</div>
          </div>
          <div class="cui-nav-column">
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Alert Dialog</div>
              <div class="cui-nav-item-description">A modal dialog that interrupts the user with important content and expects a response.</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Progress</div>
              <div class="cui-nav-item-description">Displays an indicator showing the completion progress of a task, typically...</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Tabs</div>
              <div class="cui-nav-item-description">A set of layered sections of content—known as tab panels—that are displayed one at a...</div>
            </a>
          </div>
          <div class="cui-nav-column">
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Hover Card</div>
              <div class="cui-nav-item-description">For sighted users to preview content available behind a link.</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Scroll-area</div>
              <div class="cui-nav-item-description">Visually or semantically separates content.</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Tooltip</div>
              <div class="cui-nav-item-description">A popup that displays information related to an element when the element receives...</div>
            </a>
          </div>
        </div>
      </div>
    </div>
    
    <div class="cui-nav-item-wrapper cui-nav-item-wrapper--components">
      <label for="cui-nav-components" class="cui-nav-trigger">
        Components
        <svg class="cui-nav-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </label>
      <div class="cui-nav-content cui-nav-content--components">
        <div class="cui-nav-grid">
          <div class="cui-nav-featured">
            <div class="cui-nav-featured-title">Crystal UI</div>
            <div class="cui-nav-featured-description">A lightweight CSS library with beautifully designed components.</div>
          </div>
          <div class="cui-nav-column">
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Alert Dialog</div>
              <div class="cui-nav-item-description">A modal dialog that interrupts the user with important content and expects a response.</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Progress</div>
              <div class="cui-nav-item-description">Displays an indicator showing the completion progress of a task, typically...</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Tabs</div>
              <div class="cui-nav-item-description">A set of layered sections of content—known as tab panels—that are displayed one at a...</div>
            </a>
          </div>
          <div class="cui-nav-column">
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Hover Card</div>
              <div class="cui-nav-item-description">For sighted users to preview content available behind a link.</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Scroll-area</div>
              <div class="cui-nav-item-description">Visually or semantically separates content.</div>
            </a>
            <a href="#" class="cui-nav-item">
              <div class="cui-nav-item-title">Tooltip</div>
              <div class="cui-nav-item-description">A popup that displays information related to an element when the element receives...</div>
            </a>
          </div>
        </div>
      </div>
    </div>
    
    <a href="#" class="cui-nav-trigger cui-nav-trigger--link">Docs</a>
    
    <div class="cui-nav-item-wrapper cui-nav-item-wrapper--list">
      <label for="cui-nav-list" class="cui-nav-trigger">
        List
        <svg class="cui-nav-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </label>
      <div class="cui-nav-content cui-nav-content--list">
        <a href="#" class="cui-nav-item">
          <div class="cui-nav-item-title">Components</div>
          <div class="cui-nav-item-description">Browse all components in the library.</div>
        </a>
        <a href="#" class="cui-nav-item">
          <div class="cui-nav-item-title">Documentation</div>
          <div class="cui-nav-item-description">Learn how to use the library.</div>
        </a>
        <a href="#" class="cui-nav-item">
          <div class="cui-nav-item-title">Blog</div>
          <div class="cui-nav-item-description">Read our latest blog posts.</div>
        </a>
      </div>
    </div>
    
    <div class="cui-nav-item-wrapper cui-nav-item-wrapper--simple">
      <label for="cui-nav-simple" class="cui-nav-trigger">
        Simple
        <svg class="cui-nav-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </label>
      <div class="cui-nav-content cui-nav-content--simple">
        <a href="#" class="cui-nav-link">About</a>
        <a href="#" class="cui-nav-link">Contact</a>
        <a href="#" class="cui-nav-link">Support</a>
      </div>
    </div>
    
    <div class="cui-nav-item-wrapper cui-nav-item-wrapper--with-icon">
      <label for="cui-nav-with-icon" class="cui-nav-trigger">
        With Icon
        <svg class="cui-nav-chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 6L8 10L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </label>
      <div class="cui-nav-content cui-nav-content--with-icon">
        <a href="#" class="cui-nav-item">
          <svg class="cui-nav-item-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 2V14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M2 8H14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <div class="cui-nav-item-content">
            <div class="cui-nav-item-title">Settings</div>
            <div class="cui-nav-item-description">Manage your account settings.</div>
          </div>
        </a>
        <a href="#" class="cui-nav-item">
          <svg class="cui-nav-item-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 4H14V12H2V4Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M6 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M10 2V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          <div class="cui-nav-item-content">
            <div class="cui-nav-item-title">Calendar</div>
            <div class="cui-nav-item-description">View your events and appointments.</div>
          </div>
        </a>
        <a href="#" class="cui-nav-item">
          <svg class="cui-nav-item-icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M8 4V8L10 10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <div class="cui-nav-item-content">
            <div class="cui-nav-item-title">Clock</div>
            <div class="cui-nav-item-description">Check the current time.</div>
          </div>
        </a>
      </div>
    </div>
  </div>
  
  <label for="cui-nav-home" class="cui-nav-overlay cui-nav-overlay--home"></label>
  <label for="cui-nav-components" class="cui-nav-overlay cui-nav-overlay--components"></label>
  <label for="cui-nav-list" class="cui-nav-overlay cui-nav-overlay--list"></label>
  <label for="cui-nav-simple" class="cui-nav-overlay cui-nav-overlay--simple"></label>
  <label for="cui-nav-with-icon" class="cui-nav-overlay cui-nav-overlay--with-icon"></label>
</nav>`

const css = `.cui-navigation-menu {
  position: relative;
  display: inline-block;
}

.cui-nav-checkbox {
  display: none;
}

.cui-nav-list {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: hsl(var(--background));
  border-radius: calc(var(--radius) - 2px);
  padding: 2px;
}

.cui-nav-item-wrapper {
  position: relative;
  display: inline-block;
}


.cui-nav-trigger {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  background: transparent;
  border: none;
  border-radius: calc(var(--radius) + 2px);
  cursor: pointer;
  transition: background-color 0.15s ease, color 0.15s ease;
  text-decoration: none;
  outline: none;
}

.cui-nav-trigger:hover {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-nav-trigger--link {
  cursor: default;
}

#cui-nav-home:checked ~ .cui-nav-list .cui-nav-item-wrapper--home .cui-nav-trigger,
#cui-nav-components:checked ~ .cui-nav-list .cui-nav-item-wrapper--components .cui-nav-trigger,
#cui-nav-list:checked ~ .cui-nav-list .cui-nav-item-wrapper--list .cui-nav-trigger,
#cui-nav-simple:checked ~ .cui-nav-list .cui-nav-item-wrapper--simple .cui-nav-trigger,
#cui-nav-with-icon:checked ~ .cui-nav-list .cui-nav-item-wrapper--with-icon .cui-nav-trigger {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-nav-chevron {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  color: hsl(var(--muted-foreground));
  transition: transform 0.15s ease;
}

#cui-nav-home:checked ~ .cui-nav-list .cui-nav-item-wrapper--home .cui-nav-chevron,
#cui-nav-components:checked ~ .cui-nav-list .cui-nav-item-wrapper--components .cui-nav-chevron,
#cui-nav-list:checked ~ .cui-nav-list .cui-nav-item-wrapper--list .cui-nav-chevron,
#cui-nav-simple:checked ~ .cui-nav-list .cui-nav-item-wrapper--simple .cui-nav-chevron,
#cui-nav-with-icon:checked ~ .cui-nav-list .cui-nav-item-wrapper--with-icon .cui-nav-chevron {
  transform: rotate(180deg);
}

.cui-nav-content {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  z-index: 50;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
  opacity: 0;
  pointer-events: none;
  transform: translateY(-4px);
  transition: opacity 0.15s ease, transform 0.15s ease;
  min-width: 200px;
  transition-delay: 0.1s;
}

.cui-nav-item-wrapper:hover .cui-nav-content::before,
.cui-nav-content:hover::before {
  content: '';
  position: absolute;
  top: -4px;
  left: 0;
  right: 0;
  height: 4px;
  background: transparent;
  pointer-events: auto;
}

.cui-nav-item-wrapper:hover .cui-nav-content,
.cui-nav-content:hover {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
  transition-delay: 0s;
}

.cui-nav-item-wrapper:hover .cui-nav-trigger {
  background: hsl(var(--muted));
  color: hsl(var(--foreground));
}

.cui-nav-item-wrapper:hover .cui-nav-chevron {
  transform: rotate(180deg);
}

#cui-nav-home:checked ~ .cui-nav-list .cui-nav-item-wrapper--home .cui-nav-content--home {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

#cui-nav-components:checked ~ .cui-nav-list .cui-nav-item-wrapper--components .cui-nav-content--components {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

#cui-nav-list:checked ~ .cui-nav-list .cui-nav-item-wrapper--list .cui-nav-content--list {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

#cui-nav-simple:checked ~ .cui-nav-list .cui-nav-item-wrapper--simple .cui-nav-content--simple {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

#cui-nav-with-icon:checked ~ .cui-nav-list .cui-nav-item-wrapper--with-icon .cui-nav-content--with-icon {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}

.cui-nav-content--home {
  padding: 8px;
  min-width: 600px;
}

.cui-nav-content--simple {
  padding: 4px;
  display: flex;
  flex-direction: column;
}

.cui-nav-link {
  display: flex;
  align-items: center;
  padding: 8px 12px;
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  text-decoration: none;
  border-radius: calc(var(--radius) - 2px);
  transition: background-color 0.15s ease;
  cursor: pointer;
}

.cui-nav-link:hover {
  background: hsl(var(--muted));
}

.cui-nav-content--components {
  padding: 8px;
  min-width: 600px;
}

.cui-nav-grid {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 8px;
}

.cui-nav-featured {
  padding: 16px;
  background: hsl(var(--muted));
  border-radius: calc(var(--radius) - 2px);
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cui-nav-featured-title {
  font-size: 0.875rem;
  font-weight: 600;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-nav-featured-description {
  font-size: 0.75rem;
  color: hsl(var(--muted-foreground));
  line-height: 1.5;
}

.cui-nav-column {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cui-nav-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 4px 8px;
  border-radius: calc(var(--radius) - 2px);
  text-decoration: none;
  transition: background-color 0.15s ease;
  cursor: pointer;
}

.cui-nav-item:hover {
  background: hsl(var(--muted));
}

.cui-nav-content--with-icon .cui-nav-item {
  flex-direction: row;
  align-items: flex-start;
  gap: 12px;
}

.cui-nav-item-icon {
  flex-shrink: 0;
  width: 16px;
  height: 16px;
  margin-top: 2px;
  color: hsl(var(--muted-foreground));
}

.cui-nav-item-content {
  display: flex;
  flex-direction: column;
  gap: 4px;
  flex: 1;
}

.cui-nav-item-title {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-nav-item-description {
  font-size: 0.75rem;
  color: hsl(var(--muted-foreground));
  line-height: 1.5;
}

.cui-nav-content--list {
  padding: 8px;
  min-width: 240px;
}

.cui-nav-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
  cursor: default;
}

#cui-nav-home:checked ~ .cui-nav-overlay--home,
#cui-nav-components:checked ~ .cui-nav-overlay--components,
#cui-nav-list:checked ~ .cui-nav-overlay--list,
#cui-nav-simple:checked ~ .cui-nav-overlay--simple,
#cui-nav-with-icon:checked ~ .cui-nav-overlay--with-icon {
  opacity: 1;
  pointer-events: auto;
}`

export default function NavigationMenuDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

