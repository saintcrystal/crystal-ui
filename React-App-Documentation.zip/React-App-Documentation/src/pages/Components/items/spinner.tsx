import { ComponentDoc } from '@/components/docs/ComponentDoc'

export const meta = {
  slug: 'spinner',
  name: 'Spinner',
  description: 'An indicator that can be used to show a loading state',
}

const html = `<div class="cui-spinner-card">
  <div class="cui-spinner-card-content">
    <div class="cui-spinner-card-left">
      <div class="cui-spinner"></div>
      <span class="cui-spinner-card-text">Processing payment...</span>
    </div>
    <span class="cui-spinner-card-amount">$100.00</span>
  </div>
</div>`

const css = `.cui-spinner-card {
  width: 100%;
  max-width: 400px;
  background: hsl(var(--background));
  border: 1px solid hsl(var(--border));
  border-radius: var(--radius);
  padding: 16px;
}

.cui-spinner-card-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.cui-spinner-card-left {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
  min-width: 0;
}

.cui-spinner {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid hsl(var(--muted));
  border-top-color: hsl(var(--primary));
  border-radius: 50%;
  animation: cui-spin 0.6s linear infinite;
  flex-shrink: 0;
}

.cui-spinner-card-text {
  font-size: 0.875rem;
  color: hsl(var(--foreground));
  line-height: 1.5;
}

.cui-spinner-card-amount {
  font-size: 0.875rem;
  font-weight: 500;
  color: hsl(var(--foreground));
  line-height: 1.5;
  flex-shrink: 0;
}

@keyframes cui-spin {
  to {
    transform: rotate(360deg);
  }
}`

export default function SpinnerDoc() {
  return (
    <ComponentDoc title={meta.name} description={meta.description} html={html} css={css} />
  )
}

