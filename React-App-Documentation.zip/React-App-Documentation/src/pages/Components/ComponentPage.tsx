import { useParams } from 'react-router-dom'
import { Suspense } from 'react'
import { SEO } from '@/components/SEO'
import { componentsRegistry } from './registry'

const modules = import.meta.glob('./items/*.tsx', { eager: true }) as Record<
  string,
  { default: React.ComponentType; meta?: { slug: string; name: string; description?: string } }
>

export default function ComponentPage() {
  const { slug = '' } = useParams()
  const match = Object.entries(modules).find(([, mod]) => mod.meta?.slug === slug)
  const componentMeta = componentsRegistry.find(c => c.slug === slug)

  if (!match || !componentMeta) {
    return (
      <>
        <SEO
          title="Component Not Found - Crystal UI"
          description="The requested component was not found."
          path={`/components/${slug}`}
        />
        <main className="mx-auto max-w-6xl px-4 py-10">
          <h2 className="text-3xl font-semibold">Not found</h2>
          <p className="mt-2 text-muted-foreground">Component "{slug}" is not registered.</p>
        </main>
      </>
    )
  }

  const Comp = match[1].default
  
  return (
    <>
      <SEO
        title={`${componentMeta.name} - Crystal UI | Pure CSS ${componentMeta.name} Component`}
        description={`${componentMeta.description || componentMeta.name} component for Crystal UI - pure CSS, no React required. Shadcn-style ${componentMeta.name.toLowerCase()} component.`}
        keywords={`${componentMeta.name.toLowerCase()} css, ${componentMeta.name.toLowerCase()} shadcn, ${componentMeta.name.toLowerCase()} component, pure css ${componentMeta.name.toLowerCase()}, shadcn ${componentMeta.name.toLowerCase()} css only`}
        path={`/components/${slug}`}
      />
      <Suspense>
        <Comp />
      </Suspense>
    </>
  )
}


