export type ComponentMeta = {
  slug: string
  name: string
  description?: string
}

function m(slug: string, name: string, description?: string): ComponentMeta {
  return { slug, name, description }
}

export const componentsRegistry: ComponentMeta[] = [
  m('accordion', 'Accordion', 'Collapsible content sections without JavaScript'),
  m('alert', 'Alert', 'Displays a callout for user attention'),
  m('alert-dialog', 'Alert Dialog', 'A modal dialog that interrupts the user with important content'),
  m('badge', 'Badge', 'Displays a badge or a component that looks like a badge'),
  m('breadcrumb', 'Breadcrumb', 'Displays the path to the current resource using a hierarchy of links'),
  m('button', 'Button', 'Action buttons with variants'),
  m('button-group', 'Button Group', 'A container that groups related buttons together with consistent styling'),
  m('calendar', 'Calendar', 'A date field component that allows users to enter and edit date'),
  m('card', 'Card', 'Displays a card with header, content, and footer'),
  m('checkbox', 'Checkbox', 'A control that allows the user to toggle between checked and not checked'),
  m('combobox', 'Combobox', 'Autocomplete input and command palette with a list of suggestions'),
  m('command', 'Command', 'Fast, composable, unstyled command menu for React'),
  m('data-table', 'Data Table', 'Powerful table and datagrids built using TanStack Table'),
  m('date-picker', 'Date Picker', 'A date picker component with range'),
  m('dialog', 'Dialog', 'A window overlaid on either the primary window or another dialog window, rendering the content underneath inert'),
  m('empty', 'Empty', 'A component to display empty states'),
  m('hover-card', 'Hover Card', 'For sighted users to preview content available behind a link'),
  m('input', 'Input', 'Displays a form input field or a component that looks like an input field'),
  m('input-group', 'Input Group', 'Display additional information or actions to an input or textarea'),
  m('input-otp', 'Input OTP', 'Accessible one-time password input component'),
  m('item', 'Item', 'A versatile component that you can use to display any content'),
  m('label', 'Label', 'Renders an accessible label associated with controls'),
  m('menubar', 'Menubar', 'A visually persistent menu common in desktop applications'),
  m('navigation-menu', 'Navigation Menu', 'A collection of links for navigating websites'),
  m('pagination', 'Pagination', 'Pagination with page navigation, next and previous links'),
  m('scroll-area', 'Scroll Area', 'Augments native scroll functionality for custom, cross-browser styling'),
  m('select', 'Select', 'Displays a list of options for the user to pick from—triggered by a button'),
  m('sonner', 'Sonner', 'An opinionated toast component for React'),
  m('spinner', 'Spinner', 'A loading spinner component'),
  m('switch', 'Switch', 'A control that allows the user to toggle between checked and not checked'),
  m('table', 'Table', 'A responsive table component'),
  m('tabs', 'Tabs', 'A set of layered sections of content—known as tab panels—that are displayed one at a time'),
  m('textarea', 'Textarea', 'Displays a form textarea or a component that looks like a textarea'),
  m('toggle-group', 'Toggle Group', 'A set of two-state buttons that can be toggled on or off'),
  m('typography', 'Typography', 'Text styles for headings, paragraphs, lists, and more'),
]


