import { Link } from 'react-router-dom'
import { useState, useMemo } from 'react'
import { Search } from 'lucide-react'
import { componentsRegistry } from '@/pages/Components/registry'
import { SEO } from '@/components/SEO'

export default function ComponentsIndex() {
  const [searchQuery, setSearchQuery] = useState('')
  
  const filteredItems = useMemo(() => {
    if (!searchQuery.trim()) {
      return componentsRegistry
    }
    const query = searchQuery.toLowerCase().trim()
    return componentsRegistry.filter((c) =>
      c.name.toLowerCase().includes(query) ||
      (c.description && c.description.toLowerCase().includes(query))
    )
    }, [searchQuery])

  return (
    <>
      <SEO
        title="Components - Crystal UI | Shadcn CSS Components Without React"
        description="Browse all Crystal UI components - pure CSS alternatives to Shadcn/ui. Accordion, Alert, Button, Card, Input, Select and more. No React required!"
        keywords="shadcn components css, shadcn ui components html, shadcn components without react, pure css components, crystal ui components"
        path="/components"
      />
      <main className="mx-auto max-w-6xl px-4 py-10">
        <h2 className="text-3xl font-semibold">Components</h2>
        
        <div className="mt-6 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input
            type="text"
            placeholder="Search components..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 px-10 pl-10 text-sm border border-input bg-background rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
          />
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {filteredItems.length > 0 ? (
            filteredItems.map((c) => (
              <Link
                key={c.slug}
                to={`/components/${c.slug}`}
                className="block rounded-lg border p-4 hover:bg-muted"
              >
                <div className="font-medium">{c.name}</div>
                <div className="text-sm text-muted-foreground">{c.description ?? 'Documentation'}</div>
              </Link>
            ))
          ) : (
            <div className="col-span-2 text-center py-8 text-muted-foreground">
              No components found matching "{searchQuery}"
            </div>
          )}
        </div>
      </main>
    </>
  )
}


