import { Routes, Route, Navigate } from 'react-router-dom'
import Home from '@/pages/Home'
import DocsIndex from '@/pages/Docs/Index'
import GettingStarted from '@/pages/Docs/GettingStarted'
import Installation from '@/pages/Docs/Installation'
import Theming from '@/pages/Docs/Theming'
import CssVariables from '@/pages/Docs/CssVariables'
import Customization from '@/pages/Docs/Customization'
import ComponentsIndex from '@/pages/Components/Index'
import ComponentPage from '@/pages/Components/ComponentPage'
import { Navbar } from '@/components/layout/Navbar'

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/docs" element={<DocsIndex />} />
        <Route path="/docs/getting-started" element={<GettingStarted />} />
        <Route path="/docs/installation" element={<Installation />} />
        <Route path="/docs/theming" element={<Theming />} />
        <Route path="/docs/css-variables" element={<CssVariables />} />
        <Route path="/docs/customization" element={<Customization />} />
        <Route path="/components" element={<ComponentsIndex />} />
        <Route path="/components/:slug" element={<ComponentPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  )
}
