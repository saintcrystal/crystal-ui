// CSS variable values for light and dark themes
export const cssVars = {
  light: {
    '--background': '0 0% 100%',
    '--foreground': '240 10% 3.9%',
    '--primary': '240 5.9% 10%',
    '--primary-foreground': '0 0% 98%',
    '--muted': '240 4.8% 95.9%',
    '--muted-foreground': '240 3.8% 46.1%',
    '--border': '240 5.9% 90%',
    '--input': '240 5.9% 90%',
    '--radius': '8px',
  },
  dark: {
    '--background': '240 10% 3.9%',
    '--foreground': '0 0% 98%',
    '--primary': '0 0% 98%',
    '--primary-foreground': '240 5.9% 10%',
    '--muted': '240 3.7% 15.9%',
    '--muted-foreground': '240 5% 64.9%',
    '--border': '240 3.7% 15.9%',
    '--input': '240 3.7% 15.9%',
    '--radius': '8px',
  },
}

/**
 * Replaces CSS variables with real values based on theme
 * Handles: hsl(var(--variable)), var(--variable)
 */
export function replaceCssVars(css: string, theme: 'light' | 'dark'): string {
  const vars = cssVars[theme]
  let result = css

  // Replace hsl(var(--variable)) patterns
  result = result.replace(/hsl\(var\(([^)]+)\)\)/g, (match, varName) => {
    const key = varName.trim() as keyof typeof cssVars.light
    if (vars[key]) {
      return `hsl(${vars[key]})`
    }
    return match
  })

  // Replace var(--variable) patterns (for non-hsl values like radius)
  result = result.replace(/var\(([^)]+)\)/g, (match, varName) => {
    const key = varName.trim() as keyof typeof cssVars.light
    if (vars[key]) {
      return vars[key]
    }
    return match
  })

  return result
}

