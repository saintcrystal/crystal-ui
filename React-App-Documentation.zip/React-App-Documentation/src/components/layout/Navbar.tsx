import { Link } from 'react-router-dom'
import { ThemeToggle } from '@/components/theme-toggle'
import { Github } from 'lucide-react'
import { useTheme } from 'next-themes'

export function Navbar() {
  const { theme } = useTheme()
  const fillColor = theme === 'dark' ? 'hsl(240 10% 3.9%)' : 'hsl(0 0% 100%)'
  
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link to="/" className="font-semibold flex items-center gap-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6">
              <rect x="2" y="2" width="20" height="20" rx="2" stroke="currentColor" strokeWidth="1.5" fill={fillColor}/>
              <rect x="4" y="4" width="16" height="16" rx="1" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.5"/>
              <path d="M12 6L14 10L18 12L14 14L12 18L10 14L6 12L10 10L12 6Z" fill="currentColor" opacity="0.9"/>
              <circle cx="12" cy="12" r="2" fill="currentColor" opacity="0.6"/>
            </svg>
            Crystal UI
          </Link>
          <nav className="flex items-center gap-4 text-sm">
            <Link to="/docs" className="hover:underline">
              Docs
            </Link>
            <Link to="/components" className="hover:underline">
              Components
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <a
            href="https://github.com/saintcrystal/crystal-ui"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center p-2 hover:opacity-80 transition-opacity"
            aria-label="GitHub repository"
          >
            <Github className="h-5 w-5" />
          </a>
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}


