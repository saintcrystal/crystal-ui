import { Button } from '@/components/ui/button'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { useState, useMemo } from 'react'
import { Check, Copy, ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react'
import { useTheme } from 'next-themes'
import { useNavigate, Link, useParams } from 'react-router-dom'
import { replaceCssVars } from '@/lib/css-vars'
import { componentsRegistry } from '@/pages/Components/registry'

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <Button variant="outline" size="sm" onClick={copy} className="gap-2">
      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      {copied ? 'Copied!' : `Copy ${label}`}
    </Button>
  )
}

export function ComponentDoc({
  title,
  description,
  html,
  css,
}: {
  title: string
  description?: string
  html: string
  css?: string
}) {
  const { theme } = useTheme()
  const navigate = useNavigate()
  const { slug = '' } = useParams()
  const codeStyle = theme === 'dark' ? vscDarkPlus : oneLight
  const currentTheme = (theme === 'dark' ? 'dark' : 'light') as 'light' | 'dark'
  
  // Calculate navigation based on current slug
  const navigation = useMemo(() => {
    const currentIndex = componentsRegistry.findIndex(c => c.slug === slug)
    if (currentIndex === -1) return { prev: null, next: null }
    
    const prev = currentIndex > 0 ? componentsRegistry[currentIndex - 1] : null
    const next = currentIndex < componentsRegistry.length - 1 ? componentsRegistry[currentIndex + 1] : null
    
    return {
      prev: prev ? { slug: prev.slug, name: prev.name } : null,
      next: next ? { slug: next.slug, name: next.name } : null,
    }
  }, [slug])
  
  // Replace CSS vars with real values for display
  const cssWithValues = useMemo(() => {
    return css ? replaceCssVars(css, currentTheme) : undefined
  }, [css, currentTheme])
  
  const combinedHtmlWithValues = cssWithValues ? `${html}\n<style>\n${cssWithValues}\n</style>` : html
  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-4 flex items-center justify-between">
        <Button
          variant="ghost"
          onClick={() => navigate('/components')}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Components
        </Button>
        <div className="flex items-center gap-2">
          {navigation.prev && (
            <Link to={`/components/${navigation.prev.slug}`}>
              <Button variant="outline" size="sm" className="gap-2">
                <ChevronLeft className="h-4 w-4" />
                {navigation.prev.name}
              </Button>
            </Link>
          )}
          {navigation.next && (
            <Link to={`/components/${navigation.next.slug}`}>
              <Button variant="outline" size="sm" className="gap-2">
                {navigation.next.name}
                <ChevronRight className="h-4 w-4" />
              </Button>
            </Link>
          )}
        </div>
      </div>
      <h2 className="text-3xl font-semibold">{title}</h2>
      {description ? (
        <p className="mt-2 text-muted-foreground">{description}</p>
      ) : null}

      <section className="mt-6 rounded-lg border p-6">
        {/* Live preview using raw HTML with crystal-ui.css classes */}
        {/* Only show HTML in preview, not CSS code */}
        <div dangerouslySetInnerHTML={{ __html: html }} />
      </section>

      <section className="mt-8 space-y-6">
        {html && (
          <div>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-lg font-semibold">HTML Structure</h3>
              <CopyButton text={html} label="HTML" />
            </div>
            <div className="rounded-lg border overflow-hidden">
              <SyntaxHighlighter
                language="html"
                style={codeStyle}
                customStyle={{ margin: 0, borderRadius: '0.5rem', fontSize: '14px' }}
              >
                {html}
              </SyntaxHighlighter>
            </div>
          </div>
        )}

        {css && cssWithValues && (
          <div>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-lg font-semibold">CSS Styles</h3>
              <CopyButton text={cssWithValues} label="CSS" />
            </div>
            <div className="rounded-lg border overflow-hidden">
              <SyntaxHighlighter
                language="css"
                style={codeStyle}
                customStyle={{ margin: 0, borderRadius: '0.5rem', fontSize: '14px' }}
              >
                {cssWithValues}
              </SyntaxHighlighter>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Values shown for <span className="font-medium">{currentTheme}</span> theme.
            </p>
          </div>
        )}

        {css && cssWithValues && (
          <div>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-lg font-semibold">Complete Code</h3>
              <CopyButton text={combinedHtmlWithValues} label="All" />
            </div>
            <div className="rounded-lg border overflow-hidden">
              <SyntaxHighlighter
                language="html"
                style={codeStyle}
                customStyle={{ margin: 0, borderRadius: '0.5rem', fontSize: '14px' }}
              >
                {combinedHtmlWithValues}
              </SyntaxHighlighter>
            </div>
          </div>
        )}

        <p className="mt-4 text-sm text-muted-foreground">
          Styles are provided by <code>crystal-ui.css</code>. Include it via a link tag: <code className="text-xs bg-muted px-1 py-0.5 rounded">{"<link rel=\"stylesheet\" href=\"https://crystal-ui.com/v1/crystal-ui.css\" />"}</code> and use the raw HTML shown above.
        </p>
      </section>
    </main>
  )
}
