import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { useTheme } from 'next-themes'
import type { ReactNode } from 'react'

export function CodeBlock({ children, language = 'html' }: { children: string; language?: string }) {
  const { theme } = useTheme()
  const codeStyle = theme === 'dark' ? vscDarkPlus : oneLight
  return (
    <div className="rounded-lg border overflow-hidden my-4">
      <SyntaxHighlighter
        language={language}
        style={codeStyle}
        customStyle={{ margin: 0, borderRadius: '0.5rem', fontSize: '14px' }}
      >
        {children}
      </SyntaxHighlighter>
    </div>
  )
}

export function DocsLayout({ children }: { children: ReactNode }) {
  return (
    <main className="mx-auto max-w-4xl px-4 py-12">
      <article className="prose prose-slate dark:prose-invert max-w-none">
        <div className="prose-headings:font-semibold prose-h1:text-4xl prose-h2:text-3xl prose-h2:mt-12 prose-h2:mb-4 prose-h3:text-2xl prose-h3:mt-8 prose-h3:mb-3 prose-p:text-muted-foreground prose-p:leading-7 prose-strong:text-foreground prose-strong:font-semibold prose-a:text-primary prose-a:no-underline hover:prose-a:underline prose-code:text-primary prose-code:bg-muted prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-sm prose-code:before:content-none prose-code:after:content-none prose-pre:bg-transparent prose-pre:p-0 prose-pre:border-0 prose-li:text-muted-foreground prose-li:my-2">
          {children}
        </div>
      </article>
    </main>
  )
}

