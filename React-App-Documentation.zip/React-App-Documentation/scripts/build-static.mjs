import { execSync } from 'child_process'
import { writeFileSync, readFileSync, mkdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const rootDir = join(__dirname, '..')

// First, build the app normally
console.log('Building app...')
execSync('npm run build', { stdio: 'inherit', cwd: rootDir })

// Routes to pre-render
const routes = [
  '/',
  '/docs',
  '/docs/getting-started',
  '/docs/installation',
  '/docs/theming',
  '/docs/css-variables',
  '/docs/customization',
  '/components',
  '/components/accordion',
  '/components/alert',
  '/components/alert-dialog',
  '/components/badge',
  '/components/breadcrumb',
  '/components/button',
  '/components/button-group',
  '/components/calendar',
  '/components/card',
  '/components/checkbox',
  '/components/combobox',
  '/components/command',
  '/components/data-table',
  '/components/date-picker',
  '/components/dialog',
  '/components/empty',
  '/components/hover-card',
  '/components/input',
  '/components/input-group',
  '/components/input-otp',
  '/components/item',
  '/components/label',
  '/components/menubar',
  '/components/navigation-menu',
  '/components/pagination',
  '/components/scroll-area',
  '/components/select',
  '/components/sonner',
  '/components/spinner',
  '/components/switch',
  '/components/table',
  '/components/tabs',
  '/components/textarea',
  '/components/toggle-group',
  '/components/typography',
]

console.log('Pre-rendering pages...')

// Read the built index.html
const distDir = join(rootDir, 'dist')
const indexPath = join(distDir, 'index.html')
let indexHtml = readFileSync(indexPath, 'utf-8')

// For each route, create a directory and copy index.html
routes.forEach(route => {
  const routePath = route === '/' ? distDir : join(distDir, route)
  mkdirSync(routePath, { recursive: true })
  
  // Update the base href if needed (not needed for hash routing)
  const routeHtml = indexHtml
  writeFileSync(join(routePath, 'index.html'), routeHtml)
})

console.log(`Pre-rendered ${routes.length} pages`)
console.log('Static build complete!')
