import { writeFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const rootDir = join(__dirname, '..')
const distDir = join(rootDir, 'dist')

const baseUrl = 'https://crystal-ui.com'

// Routes from the app
const routes = [
  '/',
  '/docs',
  '/docs/getting-started',
  '/docs/installation',
  '/docs/theming',
  '/docs/css-variables',
  '/docs/customization',
  '/components',
  // Components will be added dynamically
  '/components/accordion',
  '/components/alert',
  '/components/alert-dialog',
  '/components/badge',
  '/components/breadcrumb',
  '/components/button',
  '/components/button-group',
  '/components/calendar',
  '/components/card',
  '/components/checkbox',
  '/components/combobox',
  '/components/command',
  '/components/data-table',
  '/components/date-picker',
  '/components/dialog',
  '/components/empty',
  '/components/hover-card',
  '/components/input',
  '/components/input-group',
  '/components/input-otp',
  '/components/item',
  '/components/label',
  '/components/menubar',
  '/components/navigation-menu',
  '/components/pagination',
  '/components/scroll-area',
  '/components/select',
  '/components/sonner',
  '/components/spinner',
  '/components/switch',
  '/components/table',
  '/components/tabs',
  '/components/textarea',
  '/components/toggle-group',
  '/components/typography',
]

const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${routes
  .map(
    route => `  <url>
    <loc>${baseUrl}${route}</loc>
    <changefreq>weekly</changefreq>
    <priority>${route === '/' ? '1.0' : route.startsWith('/components/') ? '0.8' : '0.7'}</priority>
  </url>`
  )
  .join('\n')}
</urlset>`

// Write to both public (for dev) and dist (for production)
writeFileSync(join(distDir, 'sitemap.xml'), sitemap)
writeFileSync(join(rootDir, 'public', 'sitemap.xml'), sitemap)
console.log(`Generated sitemap.xml with ${routes.length} URLs in dist/ and public/`)
